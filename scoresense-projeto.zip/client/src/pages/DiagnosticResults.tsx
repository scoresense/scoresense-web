import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, CheckCircle2, AlertTriangle, TrendingUp, Download } from "lucide-react";
import { useEffect, useState } from "react";

const riskLevelConfig = {
  low: {
    label: "Baixo",
    color: "#10b981",
    bgColor: "bg-green-50",
    borderColor: "border-green-200",
    icon: CheckCircle2,
    description: "Seu negócio tem baixa necessidade de análise de crédito avançada. Considere manter controles básicos.",
  },
  medium: {
    label: "Médio",
    color: "#f59e0b",
    bgColor: "bg-amber-50",
    borderColor: "border-amber-200",
    icon: AlertTriangle,
    description: "Seu negócio tem necessidade moderada de análise de crédito. Recomendamos consulta básica e monitoramento.",
  },
  high: {
    label: "Alto",
    color: "#ef4444",
    bgColor: "bg-red-50",
    borderColor: "border-red-200",
    icon: TrendingUp,
    description: "Seu negócio tem alta necessidade de análise de crédito. Recomendamos serviços completos de análise e monitoramento.",
  },
  critical: {
    label: "Crítico",
    color: "#dc2626",
    bgColor: "bg-red-100",
    borderColor: "border-red-300",
    icon: AlertTriangle,
    description: "Seu negócio tem necessidade urgente de análise de crédito completa. Recomendamos implementação imediata.",
  },
};

export default function DiagnosticResults() {
  const [, navigate] = useLocation();
  const [params, setParams] = useState<{ leadId?: string; score?: string; riskLevel?: string }>({});

  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    setParams({
      leadId: searchParams.get("leadId") || undefined,
      score: searchParams.get("score") || undefined,
      riskLevel: searchParams.get("riskLevel") || undefined,
    });
  }, []);

  const score = parseInt(params.score || "0");
  const riskLevel = (params.riskLevel as keyof typeof riskLevelConfig) || "low";
  const config = riskLevelConfig[riskLevel];
  const Icon = config.icon;

  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Header */}
      <div className="bg-white border-b border-neutral-200">
        <div className="container py-6">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 text-[#1a3a52] hover:text-[#2d5a8c] transition mb-4"
          >
            <ArrowLeft className="w-4 h-4" />
            Voltar
          </button>
          <h1 className="text-3xl font-bold text-neutral-900">Resultado do Diagnóstico</h1>
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-12">
        <div className="max-w-3xl mx-auto">
          {/* Score Card */}
          <Card className={`${config.bgColor} ${config.borderColor} border-2 p-8 mb-8`}>
            <div className="flex items-center gap-6">
              <div className="flex-shrink-0">
                <Icon className="w-16 h-16" style={{ color: config.color }} />
              </div>
              <div className="flex-1">
                <h2 className="text-3xl font-bold text-neutral-900 mb-2">
                  Score de Risco: {score}/100
                </h2>
                <p className="text-xl font-semibold mb-2" style={{ color: config.color }}>
                  Nível: {config.label}
                </p>
                <p className="text-neutral-600">
                  {config.description}
                </p>
              </div>
            </div>
          </Card>

          {/* Score Breakdown */}
          <Card className="card-elevated mb-8">
            <h3 className="text-2xl font-bold text-neutral-900 mb-6">Análise Detalhada</h3>
            
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-neutral-700 font-medium">Exposição ao Risco</span>
                  <span className="text-neutral-900 font-bold">{score}%</span>
                </div>
                <div className="w-full bg-neutral-200 rounded-full h-3 overflow-hidden">
                  <div
                    className="h-full transition-all duration-500"
                    style={{
                      width: `${score}%`,
                      backgroundColor: config.color,
                    }}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8">
                <div className="p-4 bg-neutral-50 rounded-lg border border-neutral-200">
                  <p className="text-sm text-neutral-600 mb-1">Segmento</p>
                  <p className="font-semibold text-neutral-900">Distribuição/Atacado</p>
                </div>
                <div className="p-4 bg-neutral-50 rounded-lg border border-neutral-200">
                  <p className="text-sm text-neutral-600 mb-1">Volume de Clientes</p>
                  <p className="font-semibold text-neutral-900">201-500+</p>
                </div>
                <div className="p-4 bg-neutral-50 rounded-lg border border-neutral-200">
                  <p className="text-sm text-neutral-600 mb-1">Modelo de Venda</p>
                  <p className="font-semibold text-neutral-900">Misto/A Prazo</p>
                </div>
                <div className="p-4 bg-neutral-50 rounded-lg border border-neutral-200">
                  <p className="text-sm text-neutral-600 mb-1">Principal Dor</p>
                  <p className="font-semibold text-neutral-900">Múltiplas Dores</p>
                </div>
              </div>
            </div>
          </Card>

          {/* Recommendations */}
          <Card className="card-elevated mb-8">
            <h3 className="text-2xl font-bold text-neutral-900 mb-6">Recomendações Personalizadas</h3>
            
            <div className="space-y-4">
              {riskLevel === "critical" && (
                <>
                  <div className="p-4 border-l-4 border-[#dc2626] bg-red-50 rounded">
                    <h4 className="font-bold text-neutral-900 mb-2">Análise de Crédito Completa</h4>
                    <p className="text-neutral-600 text-sm">
                      Score de risco personalizado, histórico de pagamento, comportamento de mercado e análise de fluxo de caixa para decisões seguras.
                    </p>
                  </div>
                  <div className="p-4 border-l-4 border-[#dc2626] bg-red-50 rounded">
                    <h4 className="font-bold text-neutral-900 mb-2">Validação Cadastral Avançada</h4>
                    <p className="text-neutral-600 text-sm">
                      Verificação de CNPJ/CPF, dados bancários, identidade e cruzamento de informações para prevenir fraude.
                    </p>
                  </div>
                  <div className="p-4 border-l-4 border-[#dc2626] bg-red-50 rounded">
                    <h4 className="font-bold text-neutral-900 mb-2">Monitoramento Contínuo</h4>
                    <p className="text-neutral-600 text-sm">
                      Alertas em tempo real sobre mudanças no perfil do cliente e sinais de deterioração de risco.
                    </p>
                  </div>
                  <div className="p-4 border-l-4 border-[#dc2626] bg-red-50 rounded">
                    <h4 className="font-bold text-neutral-900 mb-2">Suporte a Cobrança</h4>
                    <p className="text-neutral-600 text-sm">
                      Estratégias de cobrança inteligentes, acompanhamento de inadimplência e recuperação de crédito.
                    </p>
                  </div>
                </>
              )}
              
              {riskLevel === "high" && (
                <>
                  <div className="p-4 border-l-4 border-[#ef4444] bg-red-50 rounded">
                    <h4 className="font-bold text-neutral-900 mb-2">Análise de Crédito + Score de Risco</h4>
                    <p className="text-neutral-600 text-sm">
                      Análise completa com score de risco e monitoramento de mudanças no perfil do cliente.
                    </p>
                  </div>
                  <div className="p-4 border-l-4 border-[#ef4444] bg-red-50 rounded">
                    <h4 className="font-bold text-neutral-900 mb-2">Validação Cadastral</h4>
                    <p className="text-neutral-600 text-sm">
                      Verificação de dados básicos e cruzamento de informações para segurança.
                    </p>
                  </div>
                  <div className="p-4 border-l-4 border-[#ef4444] bg-red-50 rounded">
                    <h4 className="font-bold text-neutral-900 mb-2">Monitoramento</h4>
                    <p className="text-neutral-600 text-sm">
                      Acompanhamento periódico de clientes com alertas de risco.
                    </p>
                  </div>
                </>
              )}
              
              {riskLevel === "medium" && (
                <>
                  <div className="p-4 border-l-4 border-[#f59e0b] bg-amber-50 rounded">
                    <h4 className="font-bold text-neutral-900 mb-2">Consulta Básica + Monitoramento</h4>
                    <p className="text-neutral-600 text-sm">
                      Consulta de informações cadastrais e monitoramento periódico de clientes.
                    </p>
                  </div>
                  <div className="p-4 border-l-4 border-[#f59e0b] bg-amber-50 rounded">
                    <h4 className="font-bold text-neutral-900 mb-2">Validação Cadastral Básica</h4>
                    <p className="text-neutral-600 text-sm">
                      Verificação de CNPJ/CPF para garantir informações corretas.
                    </p>
                  </div>
                </>
              )}
              
              {riskLevel === "low" && (
                <div className="p-4 border-l-4 border-[#10b981] bg-green-50 rounded">
                  <h4 className="font-bold text-neutral-900 mb-2">Consulta de Informações Cadastrais</h4>
                  <p className="text-neutral-600 text-sm">
                    Manutenção de controles básicos com consultas periódicas para garantir informações atualizadas.
                  </p>
                </div>
              )}
            </div>
          </Card>

          {/* Next Steps */}
          <Card className="card-elevated mb-8 bg-gradient-to-r from-[#1a3a52] to-[#2d5a8c] text-white">
            <h3 className="text-2xl font-bold mb-4">Próximos Passos</h3>
            <p className="mb-6">
              Baseado no seu diagnóstico, recomendamos agendar uma reunião com nossos especialistas para discutir as melhores soluções para seu negócio.
            </p>
            <div className="flex gap-4">
              <Button
                onClick={() => navigate("/appointment")}
                className="btn-secondary"
              >
                Agendar Reunião
              </Button>
              <Button
                onClick={() => window.print()}
                className="btn-outline bg-white text-[#1a3a52] border-white hover:bg-[#1a3a52] hover:text-white"
              >
                <Download className="mr-2 w-4 h-4" />
                Baixar Relatório
              </Button>
            </div>
          </Card>

          {/* CTA */}
          <div className="text-center">
            <p className="text-neutral-600 mb-4">
              Tem dúvidas? Entre em contato conosco para uma consulta gratuita.
            </p>
            <Button
              onClick={() => navigate("/")}
              className="btn-outline"
            >
              Voltar à Home
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
