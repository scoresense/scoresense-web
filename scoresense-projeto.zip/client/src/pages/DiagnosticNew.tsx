import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, ArrowRight, Loader2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { COMPANY_DATA } from "@/lib/company";

interface AssessmentData {
  name: string;
  email: string;
  company: string;
  whatsapp: string;
  segment: string; // Varejo, Indústria, Serviços, Atacado/Distribuição, Outro
  monthlyVolume: string; // 1-10, 11-50, 51-200, 200+
  mainPain: string;
  automationNeed: string; // Não preciso, Seria diferencial, É crítico
  priority: string; // Reduzir risco, Aumentar vendas, Acelerar decisões, Organizar cobrança
}

const SEGMENTS = [
  { value: "varejo", label: "Varejo" },
  { value: "industria", label: "Indústria" },
  { value: "servicos", label: "Serviços" },
  { value: "atacado", label: "Atacado/Distribuição" },
  { value: "outro", label: "Outro" },
];

const MONTHLY_VOLUMES = [
  { value: "1-10", label: "1 a 10 operações" },
  { value: "11-50", label: "11 a 50 operações" },
  { value: "51-200", label: "51 a 200 operações" },
  { value: "200+", label: "Mais de 200 operações" },
];

const PAINS_BY_SEGMENT: Record<string, { value: string; label: string }[]> = {
  varejo: [
    { value: "perda_vendas", label: "Perdo vendas por insegurança no crédito" },
    { value: "inadimplencia", label: "Alta inadimplência e difícil cobrança" },
    { value: "velocidade", label: "Decisões de crédito são muito lentas" },
    { value: "fraude", label: "Preocupação com fraudes e clientes falsos" },
  ],
  industria: [
    { value: "previsibilidade", label: "Falta previsibilidade na saúde da carteira" },
    { value: "margens", label: "Margem está sendo consumida por inadimplência" },
    { value: "crescimento", label: "Crescimento está limitado por insegurança de crédito" },
    { value: "fornecedor", label: "Dificuldade em avaliar crédito de fornecedores" },
  ],
  servicos: [
    { value: "recorrencia", label: "Clientes não recorrem por insegurança de crédito" },
    { value: "inadimplencia_servicos", label: "Inadimplência consome fluxo de caixa" },
    { value: "velocidade_servicos", label: "Preciso aprovar crédito mais rápido" },
    { value: "acompanhamento", label: "Falta acompanhamento da saúde do cliente" },
  ],
  atacado: [
    { value: "prazo", label: "Dúvida sobre prazos e limite de crédito" },
    { value: "volume_risco", label: "Volume cresceu, mas o risco também" },
    { value: "giro_caixa", label: "Preciso otimizar giro de caixa" },
    { value: "relacionamento", label: "Relacionamento comercial é afetado por rejeições" },
  ],
  outro: [
    { value: "geral", label: "Preciso entender melhor meu risco de crédito" },
  ],
};

const AUTOMATION_OPTIONS = [
  { value: "nao", label: "Não preciso de automação" },
  { value: "diferencial", label: "Seria um diferencial competitivo" },
  { value: "critico", label: "É crítico para crescer" },
];

const PRIORITIES = [
  { value: "risco", label: "Reduzir risco de inadimplência" },
  { value: "vendas", label: "Aumentar vendas com segurança" },
  { value: "velocidade", label: "Acelerar decisões de crédito" },
  { value: "cobranca", label: "Organizar e priorizar cobrança" },
];

export default function DiagnosticNew() {
  const [, navigate] = useLocation();
  const [step, setStep] = useState(0); // 0 = intro, 1-5 = questions, 6 = submitting
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<AssessmentData>({
    name: "",
    email: "",
    company: "",
    whatsapp: "",
    segment: "",
    monthlyVolume: "",
    mainPain: "",
    automationNeed: "",
    priority: "",
  });

  const handleInputChange = (field: keyof AssessmentData, value: string) => {
    setData(prev => ({ ...prev, [field]: value }));
  };

  const validateStep = (): boolean => {
    switch (step) {
      case 0:
        return !!data.name && !!data.email && !!data.company && !!data.whatsapp;
      case 1:
        return !!data.segment;
      case 2:
        return !!data.monthlyVolume;
      case 3:
        return !!data.mainPain;
      case 4:
        return !!data.automationNeed;
      case 5:
        return !!data.priority;
      default:
        return true;
    }
  };

  const handleNext = () => {
    if (!validateStep()) {
      toast.error("Por favor, preencha este campo");
      return;
    }
    if (step < 5) {
      setStep(step + 1);
    }
  };

  const handleSubmit = async () => {
    if (!validateStep()) {
      toast.error("Por favor, preencha este campo");
      return;
    }

    setLoading(true);
    setStep(6);

    try {
      // Simular envio - em produção seria um tRPC call
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Calcular score e recomendação
      let recommendationScore = 0;

      // Volume score
      if (data.monthlyVolume === "200+") recommendationScore += 3;
      else if (data.monthlyVolume === "51-200") recommendationScore += 2;
      else if (data.monthlyVolume === "11-50") recommendationScore += 1;

      // Automation need score
      if (data.automationNeed === "critico") recommendationScore += 3;
      else if (data.automationNeed === "diferencial") recommendationScore += 1;

      // Determinar recomendação
      let recommendation = "basico"; // padrão
      if (recommendationScore >= 5) {
        recommendation = "motor"; // Motor de Crédito
      } else if (recommendationScore >= 3) {
        recommendation = "avancado"; // Relatório Avançado
      }

      // Redirecionar para resultado
      const params = new URLSearchParams({
        name: data.name,
        email: data.email,
        company: data.company,
        segment: data.segment,
        volume: data.monthlyVolume,
        recommendation,
      });

      navigate(`/diagnostic/results?${params.toString()}`);
    } catch (error: any) {
      toast.error(error.message || "Erro ao processar diagnóstico");
      setStep(5);
      setLoading(false);
    }
  };

  const stepTitles = [
    "Dados de Contato",
    "Seu Negócio",
    "Volume de Crédito",
    "Principal Desafio",
    "Automação de Decisões",
    "Prioridade",
  ];

  const painOptions = PAINS_BY_SEGMENT[data.segment] || [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a1e3a] to-[#0f2a4a]">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-[#0a1e3a]/95 backdrop-blur-md border-b border-[#00d4ff]/20">
        <div className="container flex items-center justify-between py-4">
          <div
            className="flex items-center cursor-pointer hover:opacity-80 transition-opacity"
            onClick={() => navigate("/")}
          >
            <img src={COMPANY_DATA.logo} alt={COMPANY_DATA.name} className="h-14 object-contain" />
          </div>
          <Button
            onClick={() => navigate("/")}
            variant="outline"
            className="border-[#00d4ff]/50 text-[#00d4ff] hover:bg-[#00d4ff]/10"
          >
            <ArrowLeft className="mr-2 w-4 h-4" />
            Voltar
          </Button>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="bg-[#0f2a4a]/50 border-b border-[#00d4ff]/20">
        <div className="container py-6">
          <div className="mb-4">
            <div className="flex justify-between text-sm text-gray-400 mb-2">
              <span>Passo {step > 5 ? 6 : step + 1} de 6</span>
              <span>{Math.round((Math.max(1, step + 1) / 6) * 100)}%</span>
            </div>
            <div className="w-full bg-[#0a1e3a]/50 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-[#00d4ff] to-[#00b8cc] h-2 rounded-full transition-all duration-300"
                style={{ width: `${(Math.max(1, step + 1) / 6) * 100}%` }}
              />
            </div>
          </div>
          <h2 className="text-2xl font-bold text-white">
            {step > 5 ? "Processando..." : stepTitles[step]}
          </h2>
          <p className="text-gray-400 mt-2">
            {step === 0 && "Primeiro, vamos nos conhecer"}
            {step === 1 && "Qual é o seu tipo de negócio?"}
            {step === 2 && "Quantas decisões de crédito você toma por mês?"}
            {step === 3 && "Qual é o seu principal desafio?"}
            {step === 4 && "Você precisa automatizar decisões de crédito?"}
            {step === 5 && "Qual é sua prioridade número 1?"}
            {step > 5 && "Analisando seu perfil..."}
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="container py-12">
        <div className="max-w-2xl mx-auto">
          {step <= 5 && (
            <Card className="bg-[#0f2a4a]/50 border-[#00d4ff]/20 p-8 md:p-12">
              {/* Step 0: Contact Info */}
              {step === 0 && (
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-semibold text-white mb-3">
                      Nome Completo *
                    </label>
                    <input
                      type="text"
                      value={data.name}
                      onChange={(e) => handleInputChange("name", e.target.value)}
                      placeholder="Seu nome"
                      className="w-full px-4 py-3 rounded-lg bg-[#0a1e3a]/50 border border-[#00d4ff]/30 text-white placeholder-gray-500 focus:outline-none focus:border-[#00d4ff] transition"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-white mb-3">
                      Email *
                    </label>
                    <input
                      type="email"
                      value={data.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      placeholder="seu.email@empresa.com"
                      className="w-full px-4 py-3 rounded-lg bg-[#0a1e3a]/50 border border-[#00d4ff]/30 text-white placeholder-gray-500 focus:outline-none focus:border-[#00d4ff] transition"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-white mb-3">
                      Empresa *
                    </label>
                    <input
                      type="text"
                      value={data.company}
                      onChange={(e) => handleInputChange("company", e.target.value)}
                      placeholder="Nome da sua empresa"
                      className="w-full px-4 py-3 rounded-lg bg-[#0a1e3a]/50 border border-[#00d4ff]/30 text-white placeholder-gray-500 focus:outline-none focus:border-[#00d4ff] transition"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-white mb-3">
                      WhatsApp *
                    </label>
                    <input
                      type="tel"
                      value={data.whatsapp}
                      onChange={(e) => handleInputChange("whatsapp", e.target.value)}
                      placeholder="(11) 9 1234-5678"
                      className="w-full px-4 py-3 rounded-lg bg-[#0a1e3a]/50 border border-[#00d4ff]/30 text-white placeholder-gray-500 focus:outline-none focus:border-[#00d4ff] transition"
                    />
                  </div>
                </div>
              )}

              {/* Step 1: Segment */}
              {step === 1 && (
                <div className="space-y-4">
                  {SEGMENTS.map((segment) => (
                    <button
                      key={segment.value}
                      onClick={() => handleInputChange("segment", segment.value)}
                      className={`w-full p-4 rounded-lg border-2 transition text-left font-semibold ${
                        data.segment === segment.value
                          ? "bg-[#00d4ff]/20 border-[#00d4ff] text-[#00d4ff]"
                          : "bg-[#0a1e3a]/50 border-[#00d4ff]/30 text-gray-300 hover:border-[#00d4ff]/60"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        {data.segment === segment.value && (
                          <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                        )}
                        {segment.label}
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {/* Step 2: Monthly Volume */}
              {step === 2 && (
                <div className="space-y-4">
                  {MONTHLY_VOLUMES.map((volume) => (
                    <button
                      key={volume.value}
                      onClick={() => handleInputChange("monthlyVolume", volume.value)}
                      className={`w-full p-4 rounded-lg border-2 transition text-left font-semibold ${
                        data.monthlyVolume === volume.value
                          ? "bg-[#00d4ff]/20 border-[#00d4ff] text-[#00d4ff]"
                          : "bg-[#0a1e3a]/50 border-[#00d4ff]/30 text-gray-300 hover:border-[#00d4ff]/60"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        {data.monthlyVolume === volume.value && (
                          <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                        )}
                        {volume.label}
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {/* Step 3: Main Pain */}
              {step === 3 && (
                <div className="space-y-4">
                  {painOptions.map((pain) => (
                    <button
                      key={pain.value}
                      onClick={() => handleInputChange("mainPain", pain.value)}
                      className={`w-full p-4 rounded-lg border-2 transition text-left font-semibold ${
                        data.mainPain === pain.value
                          ? "bg-[#00d4ff]/20 border-[#00d4ff] text-[#00d4ff]"
                          : "bg-[#0a1e3a]/50 border-[#00d4ff]/30 text-gray-300 hover:border-[#00d4ff]/60"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        {data.mainPain === pain.value && (
                          <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                        )}
                        {pain.label}
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {/* Step 4: Automation Need */}
              {step === 4 && (
                <div className="space-y-4">
                  {AUTOMATION_OPTIONS.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => handleInputChange("automationNeed", option.value)}
                      className={`w-full p-4 rounded-lg border-2 transition text-left font-semibold ${
                        data.automationNeed === option.value
                          ? "bg-[#00d4ff]/20 border-[#00d4ff] text-[#00d4ff]"
                          : "bg-[#0a1e3a]/50 border-[#00d4ff]/30 text-gray-300 hover:border-[#00d4ff]/60"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        {data.automationNeed === option.value && (
                          <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                        )}
                        {option.label}
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {/* Step 5: Priority */}
              {step === 5 && (
                <div className="space-y-4">
                  {PRIORITIES.map((priority) => (
                    <button
                      key={priority.value}
                      onClick={() => handleInputChange("priority", priority.value)}
                      className={`w-full p-4 rounded-lg border-2 transition text-left font-semibold ${
                        data.priority === priority.value
                          ? "bg-[#00d4ff]/20 border-[#00d4ff] text-[#00d4ff]"
                          : "bg-[#0a1e3a]/50 border-[#00d4ff]/30 text-gray-300 hover:border-[#00d4ff]/60"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        {data.priority === priority.value && (
                          <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                        )}
                        {priority.label}
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {/* Buttons */}
              <div className="flex gap-4 mt-8 pt-8 border-t border-[#00d4ff]/20">
                {step > 0 && (
                  <Button
                    onClick={() => setStep(step - 1)}
                    variant="outline"
                    className="flex-1 border-[#00d4ff]/50 text-[#00d4ff] hover:bg-[#00d4ff]/10"
                  >
                    <ArrowLeft className="mr-2 w-4 h-4" />
                    Voltar
                  </Button>
                )}
                <Button
                  onClick={step === 5 ? handleSubmit : handleNext}
                  className="flex-1 bg-gradient-to-r from-[#00d4ff] to-[#00b8cc] hover:from-[#00e5ff] hover:to-[#00d4ff] text-[#0a1e3a] font-bold"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <Loader2 className="mr-2 w-4 h-4 animate-spin" />
                      Processando...
                    </>
                  ) : step === 5 ? (
                    <>
                      Ver Recomendação
                      <ArrowRight className="ml-2 w-4 h-4" />
                    </>
                  ) : (
                    <>
                      Próximo
                      <ArrowRight className="ml-2 w-4 h-4" />
                    </>
                  )}
                </Button>
              </div>
            </Card>
          )}

          {/* Loading State */}
          {step > 5 && (
            <Card className="bg-[#0f2a4a]/50 border-[#00d4ff]/20 p-12 text-center">
              <div className="flex justify-center mb-6">
                <div className="relative w-16 h-16">
                  <div className="absolute inset-0 rounded-full border-4 border-[#00d4ff]/30"></div>
                  <div
                    className="absolute inset-0 rounded-full border-4 border-transparent border-t-[#00d4ff] animate-spin"
                    style={{ borderTopColor: "#00d4ff" }}
                  ></div>
                </div>
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Analisando seu perfil</h3>
              <p className="text-gray-400">Isso vai levar alguns segundos...</p>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
