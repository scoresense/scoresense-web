import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, ArrowRight, Calendar, User, Tag, Search } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { COMPANY_DATA } from "@/lib/company";

export default function Blog() {
  const [, navigate] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [searchTerm, setSearchTerm] = useState<string>("");

  const { data: posts, isLoading } = trpc.blog.list.useQuery({ limit: 12, offset: 0 });

  const categories = [
    { value: "", label: "Todos os artigos" },
    { value: "credito", label: "Crédito" },
    { value: "serasa", label: "Serasa" },
    { value: "cobranca", label: "Cobrança" },
    { value: "fraude", label: "Fraude" },
    { value: "tendencias", label: "Tendências" },
    { value: "educacao", label: "Educação" },
  ];

  const displayedPosts = posts?.filter((post) => {
    const matchesCategory = !selectedCategory || post.category === selectedCategory;
    const matchesSearch =
      searchTerm === "" ||
      post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  }) || [];

  const formatDate = (date: Date | string | null) => {
    if (!date) return "";
    const d = new Date(date);
    return new Intl.DateTimeFormat("pt-BR", {
      day: "2-digit",
      month: "long",
      year: "numeric",
    }).format(d);
  };

  const getCategoryLabel = (category: string) => {
    return categories.find((c) => c.value === category)?.label || category;
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      credito: "from-[#00d4ff] to-[#00b8cc]",
      serasa: "from-[#ff1493] to-[#ff69b4]",
      cobranca: "from-[#ffd700] to-[#ffed4e]",
      fraude: "from-[#ff6347] to-[#ff8c00]",
      tendencias: "from-[#9370db] to-[#ba55d3]",
      educacao: "from-[#20b2aa] to-[#3cb371]",
    };
    return colors[category] || "from-[#00d4ff] to-[#00b8cc]";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a1e3a] to-[#0f2a4a]">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-[#0a1e3a]/95 backdrop-blur-md border-b border-[#00d4ff]/20">
        <div className="container flex items-center justify-between py-4">
          <div
            className="flex items-center cursor-pointer hover:opacity-80 transition-opacity"
            onClick={() => navigate("/")}
          >
            <img src={COMPANY_DATA.logo} alt={COMPANY_DATA.name} className="h-14 object-contain" />
          </div>
          <Button
            onClick={() => navigate("/")}
            variant="outline"
            className="border-[#00d4ff]/50 text-[#00d4ff] hover:bg-[#00d4ff]/10"
          >
            <ArrowLeft className="mr-2 w-4 h-4" />
            Voltar
          </Button>
        </div>
      </div>

      {/* Hero */}
      <div className="bg-gradient-to-r from-[#0f2a4a] to-[#0a1e3a] border-b border-[#00d4ff]/20 py-12">
        <div className="container">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">Blog ScoreSense</h1>
          <p className="text-xl text-gray-400 max-w-2xl">
            Artigos sobre crédito, Serasa, cobrança e prevenção de fraude. Atualizado semanalmente.
          </p>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="bg-[#0f2a4a]/50 border-b border-[#00d4ff]/20 py-8">
        <div className="container space-y-6">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="text"
              placeholder="Buscar artigos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 rounded-lg bg-[#0a1e3a]/50 border border-[#00d4ff]/30 text-white placeholder-gray-500 focus:outline-none focus:border-[#00d4ff] transition"
            />
          </div>

          {/* Categories */}
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <button
                key={category.value}
                onClick={() => setSelectedCategory(category.value)}
                className={`px-4 py-2 rounded-full font-semibold transition-all ${
                  selectedCategory === category.value
                    ? "bg-[#00d4ff] text-[#0a1e3a]"
                    : "bg-[#0a1e3a]/50 border border-[#00d4ff]/30 text-gray-300 hover:border-[#00d4ff]/60"
                }`}
              >
                {category.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Posts Grid */}
      <div className="container py-12">
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
              <Card
                key={i}
                className="bg-[#0f2a4a]/50 border-[#00d4ff]/20 p-6 animate-pulse"
              >
                <div className="h-8 bg-[#00d4ff]/20 rounded mb-4" />
                <div className="h-4 bg-[#00d4ff]/20 rounded mb-2" />
                <div className="h-4 bg-[#00d4ff]/20 rounded w-3/4" />
              </Card>
            ))}
          </div>
        ) : displayedPosts.length === 0 ? (
          <div className="text-center py-12">
            <h3 className="text-2xl font-bold text-white mb-2">Nenhum artigo encontrado</h3>
            <p className="text-gray-400">Tente ajustar sua busca ou filtros</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {displayedPosts.map((post) => (
              <Card
                key={post.id}
                className="bg-[#0f2a4a]/50 border-[#00d4ff]/20 overflow-hidden hover:border-[#00d4ff]/50 transition cursor-pointer group"
                onClick={() => navigate(`/blog/${post.slug}`)}
              >
                {/* Image */}
                {post.imageUrl && (
                  <div className="w-full h-48 bg-gradient-to-br from-[#00d4ff]/20 to-[#ff1493]/20 overflow-hidden">
                    <img
                      src={post.imageUrl}
                      alt={post.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                )}

                {/* Content */}
                <div className="p-6">
                  {/* Category Badge */}
                  <div className={`inline-block mb-4`}>
                    <span className={`text-xs font-bold px-3 py-1 rounded-full bg-gradient-to-r ${getCategoryColor(post.category)} text-white`}>
                      {getCategoryLabel(post.category)}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="text-xl font-bold text-white mb-3 line-clamp-2 group-hover:text-[#00d4ff] transition">
                    {post.title}
                  </h3>

                  {/* Excerpt */}
                  <p className="text-gray-400 text-sm mb-4 line-clamp-3">{post.excerpt}</p>

                  {/* Meta */}
                  <div className="border-t border-[#00d4ff]/20 pt-4 space-y-2">
                    <div className="flex items-center gap-2 text-xs text-gray-400">
                      <Calendar className="w-3 h-3" />
                      {formatDate(post.publishedAt)}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-gray-400">
                      <User className="w-3 h-3" />
                      {post.author}
                    </div>
                  </div>

                  {/* Read More Button */}
                  <Button
                    className="w-full mt-6 bg-gradient-to-r from-[#00d4ff] to-[#00b8cc] hover:from-[#00e5ff] hover:to-[#00d4ff] text-[#0a1e3a] font-bold"
                    onClick={(e) => {
                      e.stopPropagation();
                      navigate(`/blog/${post.slug}`);
                    }}
                  >
                    Ler Artigo
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Newsletter CTA */}
      <section className="bg-gradient-to-r from-[#0f2a4a] to-[#0a1e3a] border-y border-[#00d4ff]/20 py-12 my-12">
        <div className="container text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Receba novos artigos por email</h2>
          <p className="text-gray-400 mb-6 max-w-xl mx-auto">
            Inscreva-se na nossa newsletter para receber semanalmente artigos sobre crédito, Serasa e gestão de risco.
          </p>
          <Button className="bg-gradient-to-r from-[#00d4ff] to-[#00b8cc] hover:from-[#00e5ff] hover:to-[#00d4ff] text-[#0a1e3a] font-bold px-8 py-6">
            Inscrever
          </Button>
        </div>
      </section>
    </div>
  );
}
