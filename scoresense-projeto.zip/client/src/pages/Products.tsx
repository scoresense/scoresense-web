import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { ArrowRight, BarChart3, CheckCircle, Database, Lock, Zap } from "lucide-react";
import { Link } from "wouter";
import { COMPANY_DATA } from "@/lib/company";

export default function Products() {
  const { isAuthenticated } = useAuth();

  const solutions = [
    {
      id: 1,
      title: "Análise de Crédito PJ",
      description: "Conhecer melhor empresas, perfil de risco, informações negativas e dados de mercado.",
      icon: BarChart3,
      benefits: [
        "Avaliação completa de risco de crédito",
        "Acesso a informações negativas e positivas",
        "Dados de mercado e comportamento",
        "Decisões mais seguras e rápidas"
      ],
      color: "from-cyan-400 to-cyan-500"
    },
    {
      id: 2,
      title: "Validações Cadastrais",
      description: "Apoiar triagem e higienização de leads, clientes e cadastros.",
      icon: CheckCircle,
      benefits: [
        "Verificação de dados cadastrais",
        "Detecção de inconsistências",
        "Higienização de base de dados",
        "Redução de fraude cadastral"
      ],
      color: "from-magenta-400 to-magenta-500"
    },
    {
      id: 3,
      title: "Cobrança Inteligente",
      description: "Organizar recuperação com dados, priorização e estratégias de contato.",
      icon: Zap,
      benefits: [
        "Priorização de devedores",
        "Estratégias de contato otimizadas",
        "Aumento de taxa de recuperação",
        "Redução de custos operacionais"
      ],
      color: "from-cyan-400 via-magenta-400 to-magenta-500"
    },
    {
      id: 4,
      title: "Motores de Decisão",
      description: "Automatizar regras, reduzir subjetividade e dar escala à política de crédito.",
      icon: Database,
      benefits: [
        "Automação de decisões de crédito",
        "Redução de subjetividade",
        "Escalabilidade de processos",
        "Consistência nas aprovações"
      ],
      color: "from-magenta-400 via-cyan-400 to-cyan-500"
    },
    {
      id: 5,
      title: "Recebíveis e Risco Sacado",
      description: "Ampliar visão financeira e apoiar decisões com base no comportamento de recebíveis.",
      icon: Lock,
      benefits: [
        "Visão completa de recebíveis",
        "Análise de risco de sacado",
        "Previsibilidade de fluxo",
        "Proteção de receita"
      ],
      color: "from-cyan-400 to-magenta-500"
    }
  ];

  return (
    <div className="min-h-screen bg-[#0a1e3a]">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-[#0a1e3a]/95 backdrop-blur supports-[backdrop-filter]:bg-[#0a1e3a]/60 border-b border-cyan-500/20">
        <div className="container flex items-center justify-between h-20">
          <Link href="/" className="flex items-center hover:opacity-80 transition-opacity">
            <img src={COMPANY_DATA.logo} alt={COMPANY_DATA.name} className="h-14 object-contain" />
          </Link>
          <nav className="hidden md:flex items-center gap-8">
            <Link href="/" className="text-gray-300 hover:text-cyan-400 transition-colors">Home</Link>
            <Link href="/about" className="text-gray-300 hover:text-cyan-400 transition-colors">Quem Somos</Link>
            <Link href="/products" className="text-cyan-400 font-medium">Produtos</Link>
            <Link href="/diagnostic" className="text-gray-300 hover:text-cyan-400 transition-colors">Diagnóstico</Link>
            {isAuthenticated && <Link href="/admin" className="text-gray-300 hover:text-cyan-400 transition-colors">Admin</Link>}
          </nav>
        </div>
      </header>

      {/* Hero Section com Imagem */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="/manus-storage/solucoes-produtos_1864f894.png"
            alt="Soluções Serasa"
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0a1e3a] via-[#0a1e3a]/70 to-[#0a1e3a]/40"></div>
        </div>
        
        <div className="container relative z-10">
          <div className="max-w-3xl">
            <div className="inline-block px-4 py-2 rounded-full border border-cyan-400/30 bg-cyan-400/10 text-cyan-400 text-sm font-medium mb-6">
              Soluções Serasa
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight text-white">
              Soluções Serasa para Seu Negócio
            </h1>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              Conheça as soluções que ajudam empresas a reduzir inadimplência, prevenir fraude e tomar decisões de crédito mais rápidas e seguras.
            </p>
          </div>
        </div>
      </section>

      {/* Soluções */}
      <section className="py-20 border-b border-cyan-500/20">
        <div className="container">
          <h2 className="text-4xl font-bold mb-4 text-white">Soluções em Destaque</h2>
          <p className="text-lg text-gray-300 mb-16 max-w-2xl">
            Temas que costumam abrir conversas de alto valor
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {solutions.map((solution) => {
              const Icon = solution.icon;
              return (
                <div 
                  key={solution.id} 
                  className="group p-8 rounded-xl border border-cyan-500/20 bg-gradient-to-br from-cyan-500/5 to-magenta-500/5 hover:border-cyan-400/40 transition-all duration-300"
                >
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${solution.color} flex items-center justify-center mb-4 group-hover:shadow-lg transition-all duration-300`}>
                    <Icon className="w-6 h-6 text-[#0a1e3a]" />
                  </div>
                  <h3 className="text-xl font-bold mb-3 text-white">{solution.title}</h3>
                  <p className="text-gray-300 mb-6">{solution.description}</p>
                  
                  <div className="space-y-2 mb-6">
                    {solution.benefits.map((benefit, i) => (
                      <div key={i} className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-cyan-400 mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-gray-300">{benefit}</span>
                      </div>
                    ))}
                  </div>

                  <Link href="/diagnostic">
                    <Button className="w-full bg-cyan-500 hover:bg-cyan-600 text-[#0a1e3a] font-bold transition-all duration-300">
                      Saber Mais <ArrowRight className="ml-2 w-4 h-4" />
                    </Button>
                  </Link>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Comparativo com Imagem */}
      <section className="py-20 border-b border-cyan-500/20">
        <div className="container">
          <h2 className="text-4xl font-bold mb-4 text-white">Por Que Escolher Serasa?</h2>
          <p className="text-lg text-gray-300 mb-10 max-w-3xl">
            Dados confiáveis, tecnologia avançada e suporte especializado
          </p>

          {/* Texto institucional de valor */}
          <div className="mb-16 max-w-4xl space-y-5">
            <p className="text-lg text-gray-200 leading-relaxed">
              A <span className="font-semibold text-cyan-300">Serasa Experian</span> é referência nacional em
              inteligência de dados, crédito, autenticação, prevenção à fraude, cobrança e gestão de carteira.
              Criada em <span className="font-semibold text-white">1968</span>, carrega quase
              <span className="font-semibold text-white"> 58 anos de história</span> no mercado brasileiro e combina a
              força da marca Serasa com a presença global da Experian. É reconhecida como a
              <span className="font-semibold text-cyan-300"> primeira e maior Datatech do Brasil</span> e atua com
              soluções que apoiam empresas em todas as etapas da jornada do cliente: da prospecção à recuperação de crédito.
            </p>
            <p className="text-lg text-gray-200 leading-relaxed">
              Com a Serasa, sua empresa acessa <span className="font-semibold text-white">dados, tecnologia e
              inteligência</span> para vender melhor, conceder crédito com mais segurança, reduzir riscos,
              prevenir fraudes e tomar decisões comerciais com mais confiança.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-8 rounded-xl border border-cyan-500/20 bg-gradient-to-br from-cyan-500/10 to-transparent text-center">
                <div className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-magenta-400 bg-clip-text text-transparent mb-2">500+</div>
                <p className="text-gray-300">Empresas confiam em nossas soluções</p>
              </div>
              <div className="p-8 rounded-xl border border-cyan-500/20 bg-gradient-to-br from-magenta-500/10 to-transparent text-center">
                <div className="text-4xl font-bold bg-gradient-to-r from-magenta-400 to-cyan-400 bg-clip-text text-transparent mb-2">98%</div>
                <p className="text-gray-300">Precisão em análise de crédito</p>
              </div>
              <div className="p-8 rounded-xl border border-cyan-500/20 bg-gradient-to-br from-cyan-500/10 to-transparent text-center">
                <div className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-magenta-400 bg-clip-text text-transparent mb-2">24h</div>
                <p className="text-gray-300">Tempo de resposta médio</p>
              </div>
              <div className="p-8 rounded-xl border border-cyan-500/20 bg-gradient-to-br from-magenta-500/10 to-transparent text-center">
                <div className="text-4xl font-bold bg-gradient-to-r from-magenta-400 to-cyan-400 bg-clip-text text-transparent mb-2">85%</div>
                <p className="text-gray-300">Redução de risco</p>
              </div>
            </div>

            <div className="relative">
              <img 
                src="/manus-storage/tecnologia-ia_13a91d14.png"
                alt="Tecnologia e IA"
                className="rounded-xl border border-cyan-500/20 shadow-2xl"
              />
              <div className="absolute inset-0 rounded-xl bg-gradient-to-t from-[#0a1e3a] via-transparent to-transparent opacity-40"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Segurança e Compliance */}
      <section className="py-20 border-b border-cyan-500/20">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <img 
                src="/manus-storage/prevencao-fraude_c8dd7306.png"
                alt="Segurança e Prevenção"
                className="rounded-xl border border-cyan-500/20 shadow-2xl"
              />
              <div className="absolute inset-0 rounded-xl bg-gradient-to-t from-[#0a1e3a] via-transparent to-transparent opacity-40"></div>
            </div>

            <div>
              <h2 className="text-4xl font-bold mb-6 text-white">Segurança e Compliance</h2>
              <p className="text-lg text-gray-300 mb-8">
                A segurança é uma prioridade para nós. Seguimos as melhores práticas do mercado, incluindo conformidade com a LGPD, compliance, uso de tecnologias de criptografia e auditorias regulares para proteger os dados de nossos clientes.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-400 to-cyan-500 flex items-center justify-center flex-shrink-0 mt-1">
                    <CheckCircle className="w-5 h-5 text-[#0a1e3a]" />
                  </div>
                  <div>
                    <h3 className="font-bold text-white mb-1">LGPD Compliant</h3>
                    <p className="text-gray-300 text-sm">Conformidade total com Lei Geral de Proteção de Dados</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-magenta-400 to-magenta-500 flex items-center justify-center flex-shrink-0 mt-1">
                    <CheckCircle className="w-5 h-5 text-[#0a1e3a]" />
                  </div>
                  <div>
                    <h3 className="font-bold text-white mb-1">Criptografia End-to-End</h3>
                    <p className="text-gray-300 text-sm">Proteção máxima de dados em trânsito e em repouso</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-400 via-magenta-400 to-magenta-500 flex items-center justify-center flex-shrink-0 mt-1">
                    <CheckCircle className="w-5 h-5 text-[#0a1e3a]" />
                  </div>
                  <div>
                    <h3 className="font-bold text-white mb-1">Auditorias Regulares</h3>
                    <p className="text-gray-300 text-sm">Verificações contínuas de segurança e conformidade</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-r from-[#0a1e3a] via-cyan-500/10 to-[#0a1e3a] border-b border-cyan-500/20">
        <div className="container text-center">
          <h2 className="text-4xl font-bold mb-6 text-white">Qual Solução Faz Sentido para Você?</h2>
          <p className="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">
            Faça um diagnóstico gratuito e descubra qual solução Serasa é ideal para seu negócio.
          </p>
          <Link href="/diagnostic">
            <Button className="bg-cyan-500 hover:bg-cyan-600 text-[#0a1e3a] font-bold px-8 py-3 rounded-lg transition-all duration-300">
              Fazer Diagnóstico Gratuito <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#051018] text-gray-400 py-12 border-t border-cyan-500/20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <img src={COMPANY_DATA.logo} alt={COMPANY_DATA.name} className="h-12 object-contain mb-3" />
              <p className="text-sm text-gray-400">{COMPANY_DATA.tagline}</p>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">Navegação</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="/" className="text-gray-400 hover:text-cyan-400 transition-colors">Home</Link></li>
                <li><Link href="/about" className="text-gray-400 hover:text-cyan-400 transition-colors">Quem Somos</Link></li>
                <li><Link href="/products" className="text-gray-400 hover:text-cyan-400 transition-colors">Produtos</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">Contato</h4>
              <ul className="space-y-2 text-sm">
                <li><a href={`tel:${COMPANY_DATA.phone}`} className="text-gray-400 hover:text-cyan-400 transition-colors">{COMPANY_DATA.phone}</a></li>
                <li><a href={`mailto:${COMPANY_DATA.email}`} className="text-gray-400 hover:text-cyan-400 transition-colors">{COMPANY_DATA.email}</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">Redes Sociais</h4>
              <ul className="space-y-2 text-sm">
                <li><a href={COMPANY_DATA.social.linkedin} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-cyan-400 transition-colors">LinkedIn</a></li>
                <li><a href={COMPANY_DATA.social.instagram} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-cyan-400 transition-colors">Instagram</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-cyan-500/20 pt-8 text-center text-sm text-gray-500">
            <p>&copy; 2026 ScoreSense. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
