import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Loader2, CheckCircle2, AlertCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { COMPANY_DATA } from "@/lib/company";

export default function AdminBlog() {
  const [, navigate] = useLocation();
  const [isSeeding, setIsSeeding] = useState(false);
  const [seedResult, setSeedResult] = useState<{ success: boolean; message: string } | null>(null);

  const seedPosts = async () => {
    setIsSeeding(true);
    setSeedResult(null);
    
    try {
      const result = await trpc.blog.seedInitialPosts.mutate();
      setSeedResult(result);
      toast.success(result.message);
    } catch (error: any) {
      const message = error.message || "Erro ao inserir posts";
      setSeedResult({ success: false, message });
      toast.error(message);
    } finally {
      setIsSeeding(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a1e3a] to-[#0f2a4a]">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-[#0a1e3a]/95 backdrop-blur-md border-b border-[#00d4ff]/20">
        <div className="container flex items-center justify-between py-4">
          <div
            className="flex items-center cursor-pointer hover:opacity-80 transition-opacity"
            onClick={() => navigate("/")}
          >
            <img src={COMPANY_DATA.logo} alt={COMPANY_DATA.name} className="h-14 object-contain" />
          </div>
          <Button
            onClick={() => navigate("/")}
            variant="outline"
            className="border-[#00d4ff]/50 text-[#00d4ff] hover:bg-[#00d4ff]/10"
          >
            <ArrowLeft className="mr-2 w-4 h-4" />
            Voltar
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="container py-12">
        <div className="max-w-2xl mx-auto">
          <Card className="bg-[#0f2a4a]/50 border-[#00d4ff]/20 p-8">
            <h1 className="text-4xl font-bold text-white mb-4">Admin - Blog</h1>
            <p className="text-gray-400 mb-8">
              Painel de administração para gerenciar posts do blog.
            </p>

            {/* Seed Section */}
            <div className="bg-[#00d4ff]/10 border border-[#00d4ff]/30 rounded-lg p-6 mb-8">
              <h2 className="text-2xl font-bold text-white mb-4">Inserir Posts Iniciais</h2>
              <p className="text-gray-300 mb-6">
                Clique no botão abaixo para inserir automaticamente os 4 posts de blog (Crédito, Serasa, Cobrança, Fraude).
              </p>
              <p className="text-sm text-gray-400 mb-6">
                <strong>Nota:</strong> Isso só precisa ser feito uma vez. Se já existem posts, você verá um aviso.
              </p>

              <Button
                onClick={seedPosts}
                disabled={isSeeding}
                className="w-full bg-gradient-to-r from-[#00d4ff] to-[#00b8cc] hover:from-[#00e5ff] hover:to-[#00d4ff] text-[#0a1e3a] font-bold py-6 text-lg"
              >
                {isSeeding ? (
                  <>
                    <Loader2 className="mr-2 w-5 h-5 animate-spin" />
                    Inserindo posts...
                  </>
                ) : (
                  "Inserir 4 Posts Iniciais"
                )}
              </Button>

              {/* Result */}
              {seedResult && (
                <div
                  className={`mt-6 p-4 rounded-lg flex items-start gap-3 ${
                    seedResult.success
                      ? "bg-green-500/20 border border-green-500/30"
                      : "bg-red-500/20 border border-red-500/30"
                  }`}
                >
                  {seedResult.success ? (
                    <CheckCircle2 className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                  )}
                  <div>
                    <p className={seedResult.success ? "text-green-300" : "text-red-300"}>
                      {seedResult.message}
                    </p>
                    {seedResult.success && (
                      <p className="text-sm text-green-300/70 mt-2">
                        ✓ Acesse <a href="/blog" className="underline">o blog</a> para ver os posts!
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Posts List */}
            <div>
              <h2 className="text-2xl font-bold text-white mb-4">Posts que Serão Inseridos</h2>
              <div className="space-y-4">
                {[
                  {
                    title: "Por Que Sua Empresa Perde Vendas Por Insegurança no Crédito",
                    category: "Crédito",
                    slug: "por-que-empresa-perde-vendas-inseguranca-credito",
                  },
                  {
                    title: "O que é Score de Crédito e Por Que Você Precisa Acompanhar",
                    category: "Serasa",
                    slug: "o-que-e-score-de-credito-por-que-precisa-acompanhar",
                  },
                  {
                    title: "Como Organizar e Priorizar Cobranças com Dados",
                    category: "Cobrança",
                    slug: "como-organizar-priorizar-cobrancas-com-dados",
                  },
                  {
                    title: "Detecção de Fraudes: Como Não Cair em Golpes Cadastrais",
                    category: "Fraude",
                    slug: "deteccao-fraudes-como-nao-cair-golpes-cadastrais",
                  },
                ].map((post, i) => (
                  <div key={i} className="bg-[#0a1e3a]/50 border border-[#00d4ff]/20 rounded-lg p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <h3 className="font-bold text-white mb-1">{post.title}</h3>
                        <p className="text-sm text-gray-400">
                          Categoria: <span className="text-[#00d4ff]">{post.category}</span>
                        </p>
                        <p className="text-xs text-gray-500 mt-2">Slug: {post.slug}</p>
                      </div>
                      <div className="text-[#00d4ff] text-2xl">✓</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
