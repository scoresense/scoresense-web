import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, LogOut, Filter, Eye, MoreVertical, Loader2 } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface Lead {
  id: number;
  name: string;
  company: string;
  position: string;
  whatsapp: string;
  email?: string;
  source: string;
  status: string;
  createdAt: Date;
  diagnostic?: {
    score: number;
    riskLevel: string;
    mainPain: string;
    recommendation: string;
  };
}

export default function AdminDashboard() {
  const [, navigate] = useLocation();
  const { user, logout, loading: authLoading } = useAuth();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterSource, setFilterSource] = useState("all");
  const [loading, setLoading] = useState(false);

  const listLeads = trpc.admin.leads.list.useQuery(
    {
      status: filterStatus !== "all" ? filterStatus : undefined,
      source: filterSource !== "all" ? filterSource : undefined,
      limit: 50,
    },
    { enabled: !!user && user.role === "admin" }
  );

  const updateStatus = trpc.admin.leads.updateStatus.useMutation();

  useEffect(() => {
    if (authLoading) return;
    if (!user || user.role !== "admin") {
      navigate("/");
      return;
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (listLeads.data) {
      setLeads(listLeads.data as any);
    }
  }, [listLeads.data]);

  const handleStatusChange = async (leadId: number, newStatus: string) => {
    try {
      await updateStatus.mutateAsync({ id: leadId, status: newStatus });
      setLeads(leads.map(l => l.id === leadId ? { ...l, status: newStatus } : l));
      toast.success("Status atualizado com sucesso");
    } catch (error: any) {
      toast.error(error.message || "Erro ao atualizar status");
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-neutral-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-[#1a3a52]" />
      </div>
    );
  }

  if (!user || user.role !== "admin") {
    return (
      <div className="min-h-screen bg-neutral-50 flex items-center justify-center">
        <Card className="card-elevated max-w-md text-center">
          <h2 className="text-2xl font-bold text-neutral-900 mb-4">Acesso Negado</h2>
          <p className="text-neutral-600 mb-6">
            Você não tem permissão para acessar esta página.
          </p>
          <Button
            onClick={() => navigate("/")}
            className="btn-primary w-full"
          >
            Voltar à Home
          </Button>
        </Card>
      </div>
    );
  }

  const riskLevelColors: Record<string, string> = {
    low: "bg-green-100 text-green-800",
    medium: "bg-yellow-100 text-yellow-800",
    high: "bg-orange-100 text-orange-800",
    critical: "bg-red-100 text-red-800",
  };

  const statusColors: Record<string, string> = {
    new: "bg-blue-100 text-blue-800",
    contacted: "bg-purple-100 text-purple-800",
    qualified: "bg-green-100 text-green-800",
    rejected: "bg-gray-100 text-gray-800",
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Header */}
      <div className="bg-white border-b border-neutral-200 sticky top-0 z-40">
        <div className="container py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">Painel Administrativo</h1>
            <p className="text-sm text-neutral-600">Bem-vindo, {user.name}</p>
          </div>
          <Button
            onClick={handleLogout}
            className="btn-outline"
          >
            <LogOut className="mr-2 w-4 h-4" />
            Sair
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
          {/* Stats */}
          <Card className="card text-center">
            <div className="text-3xl font-bold text-[#1a3a52] mb-2">{leads.length}</div>
            <p className="text-neutral-600">Total de Leads</p>
          </Card>
          <Card className="card text-center">
            <div className="text-3xl font-bold text-[#10b981] mb-2">
              {leads.filter(l => l.status === "qualified").length}
            </div>
            <p className="text-neutral-600">Qualificados</p>
          </Card>
          <Card className="card text-center">
            <div className="text-3xl font-bold text-[#f59e0b] mb-2">
              {leads.filter(l => l.status === "new").length}
            </div>
            <p className="text-neutral-600">Novos</p>
          </Card>
          <Card className="card text-center">
            <div className="text-3xl font-bold text-[#2d5a8c] mb-2">
              {leads.filter(l => l.diagnostic && l.diagnostic.score >= 51).length}
            </div>
            <p className="text-neutral-600">Alto Risco</p>
          </Card>
        </div>

        {/* Filters */}
        <Card className="card mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <label className="block text-sm font-medium text-neutral-900 mb-2">
                <Filter className="w-4 h-4 inline mr-2" />
                Status
              </label>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="input-field"
              >
                <option value="all">Todos</option>
                <option value="new">Novo</option>
                <option value="contacted">Contatado</option>
                <option value="qualified">Qualificado</option>
                <option value="rejected">Rejeitado</option>
              </select>
            </div>
            <div className="flex-1">
              <label className="block text-sm font-medium text-neutral-900 mb-2">
                Fonte
              </label>
              <select
                value={filterSource}
                onChange={(e) => setFilterSource(e.target.value)}
                className="input-field"
              >
                <option value="all">Todas</option>
                <option value="diagnostic">Diagnóstico</option>
                <option value="appointment">Agendamento</option>
              </select>
            </div>
          </div>
        </Card>

        {/* Leads Table */}
        <Card className="card-elevated overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-neutral-50 border-b border-neutral-200">
                <tr>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-neutral-900">Empresa</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-neutral-900">Contato</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-neutral-900">Fonte</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-neutral-900">Score</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-neutral-900">Status</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-neutral-900">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200">
                {leads.map(lead => (
                  <tr key={lead.id} className="hover:bg-neutral-50 transition">
                    <td className="px-6 py-4">
                      <div>
                        <p className="font-semibold text-neutral-900">{lead.company}</p>
                        <p className="text-sm text-neutral-600">{lead.name}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div>
                        <p className="text-sm text-neutral-900">{lead.position}</p>
                        <p className="text-sm text-neutral-600">{lead.whatsapp}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm font-medium text-neutral-600">
                        {lead.source === "diagnostic" ? "Diagnóstico" : "Agendamento"}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      {lead.diagnostic ? (
                        <div className="flex items-center gap-2">
                          <span className={`px-2 py-1 rounded text-xs font-semibold ${riskLevelColors[lead.diagnostic.riskLevel] || "bg-gray-100"}`}>
                            {lead.diagnostic.score}
                          </span>
                        </div>
                      ) : (
                        <span className="text-sm text-neutral-600">-</span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 rounded text-xs font-semibold ${statusColors[lead.status] || "bg-gray-100"}`}>
                        {lead.status === "new" && "Novo"}
                        {lead.status === "contacted" && "Contatado"}
                        {lead.status === "qualified" && "Qualificado"}
                        {lead.status === "rejected" && "Rejeitado"}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        <Button
                          onClick={() => setSelectedLead(lead)}
                          className="btn-outline text-xs"
                        >
                          <Eye className="w-3 h-3" />
                        </Button>
                        <div className="relative group">
                          <button className="p-2 hover:bg-neutral-200 rounded transition">
                            <MoreVertical className="w-4 h-4 text-neutral-600" />
                          </button>
                          <div className="absolute right-0 mt-2 w-40 bg-white rounded-lg shadow-lg hidden group-hover:block z-50">
                            {["new", "contacted", "qualified", "rejected"].map(status => (
                              <button
                                key={status}
                                onClick={() => handleStatusChange(lead.id, status)}
                                className="block w-full text-left px-4 py-2 text-sm text-neutral-700 hover:bg-neutral-100 first:rounded-t-lg last:rounded-b-lg"
                              >
                                {status === "new" && "Marcar como Novo"}
                                {status === "contacted" && "Marcar como Contatado"}
                                {status === "qualified" && "Marcar como Qualificado"}
                                {status === "rejected" && "Marcar como Rejeitado"}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {leads.length === 0 && (
            <div className="text-center py-12">
              <p className="text-neutral-600">Nenhum lead encontrado</p>
            </div>
          )}
        </Card>
      </div>

      {/* Detail Modal */}
      {selectedLead && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <Card className="card-elevated max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-neutral-900">Detalhes do Lead</h2>
              <button
                onClick={() => setSelectedLead(null)}
                className="text-neutral-600 hover:text-neutral-900 transition"
              >
                ✕
              </button>
            </div>

            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-bold text-neutral-900 mb-4">Informações de Contato</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-neutral-600">Nome</p>
                    <p className="font-semibold text-neutral-900">{selectedLead.name}</p>
                  </div>
                  <div>
                    <p className="text-sm text-neutral-600">Empresa</p>
                    <p className="font-semibold text-neutral-900">{selectedLead.company}</p>
                  </div>
                  <div>
                    <p className="text-sm text-neutral-600">Cargo</p>
                    <p className="font-semibold text-neutral-900">{selectedLead.position}</p>
                  </div>
                  <div>
                    <p className="text-sm text-neutral-600">WhatsApp</p>
                    <p className="font-semibold text-neutral-900">{selectedLead.whatsapp}</p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-sm text-neutral-600">Email</p>
                    <p className="font-semibold text-neutral-900">{selectedLead.email || "-"}</p>
                  </div>
                </div>
              </div>

              {selectedLead.diagnostic && (
                <div className="border-t border-neutral-200 pt-6">
                  <h3 className="text-lg font-bold text-neutral-900 mb-4">Diagnóstico</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-neutral-600">Score</p>
                      <p className="font-semibold text-neutral-900">{selectedLead.diagnostic.score}/100</p>
                    </div>
                    <div>
                      <p className="text-sm text-neutral-600">Nível de Risco</p>
                      <span className={`inline-block px-2 py-1 rounded text-xs font-semibold ${riskLevelColors[selectedLead.diagnostic.riskLevel]}`}>
                        {selectedLead.diagnostic.riskLevel}
                      </span>
                    </div>
                    <div className="col-span-2">
                      <p className="text-sm text-neutral-600">Principal Dor</p>
                      <p className="font-semibold text-neutral-900">{selectedLead.diagnostic.mainPain}</p>
                    </div>
                    <div className="col-span-2">
                      <p className="text-sm text-neutral-600">Recomendação</p>
                      <p className="font-semibold text-neutral-900">{selectedLead.diagnostic.recommendation}</p>
                    </div>
                  </div>
                </div>
              )}

              <div className="border-t border-neutral-200 pt-6">
                <p className="text-sm text-neutral-600 mb-2">Data de Criação</p>
                <p className="font-semibold text-neutral-900">
                  {new Date(selectedLead.createdAt).toLocaleDateString("pt-BR")}
                </p>
              </div>

              <div className="flex gap-4">
                <Button
                  onClick={() => setSelectedLead(null)}
                  className="btn-outline flex-1"
                >
                  Fechar
                </Button>
                <Button
                  onClick={() => {
                    window.open(`https://wa.me/55${selectedLead.whatsapp.replace(/\D/g, "")}`, "_blank");
                  }}
                  className="btn-primary flex-1"
                >
                  Contatar via WhatsApp
                </Button>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
