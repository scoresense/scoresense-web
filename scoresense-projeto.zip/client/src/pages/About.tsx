import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, Target, Users, Zap, Shield, TrendingUp } from "lucide-react";
import { Link } from "wouter";
import { COMPANY_DATA } from "@/lib/company";

export default function About() {
  const { isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-[#0a1e3a]">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-[#0a1e3a]/95 backdrop-blur supports-[backdrop-filter]:bg-[#0a1e3a]/60 border-b border-cyan-500/20">
        <div className="container flex items-center justify-between h-20">
          <Link href="/" className="flex items-center hover:opacity-80 transition-opacity">
            <img src={COMPANY_DATA.logo} alt={COMPANY_DATA.name} className="h-14 object-contain" />
          </Link>
          <nav className="hidden md:flex items-center gap-8">
            <Link href="/" className="text-gray-300 hover:text-cyan-400 transition-colors">Home</Link>
            <Link href="/about" className="text-cyan-400 font-medium">Quem Somos</Link>
            <Link href="/products" className="text-gray-300 hover:text-cyan-400 transition-colors">Produtos</Link>
            <Link href="/diagnostic" className="text-gray-300 hover:text-cyan-400 transition-colors">Diagnóstico</Link>
            {isAuthenticated && <Link href="/admin" className="text-gray-300 hover:text-cyan-400 transition-colors">Admin</Link>}
          </nav>
        </div>
      </header>

      {/* Hero Section com Imagem */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="/manus-storage/quem-somos-hero_f904d4e6.png"
            alt="Time ScoreSense"
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0a1e3a] via-[#0a1e3a]/70 to-[#0a1e3a]/40"></div>
        </div>
        
        <div className="container relative z-10">
          <div className="max-w-3xl">
            <div className="inline-block px-4 py-2 rounded-full border border-cyan-400/30 bg-cyan-400/10 text-cyan-400 text-sm font-medium mb-6">
              Transformação Digital em Crédito
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight text-white">
              Transformando Dados em Crescimento Seguro
            </h1>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              A ScoreSense é uma empresa de atendimento consultivo especializada em soluções Serasa Experian, traduzindo tecnologia em linguagem de negócio para empresas que vendem, concedem crédito e precisam crescer com segurança.
            </p>
          </div>
        </div>
      </section>

      {/* Missão, Visão, Valores */}
      <section className="py-20 border-b border-cyan-500/20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <div className="group p-8 rounded-xl border border-cyan-500/20 bg-gradient-to-br from-cyan-500/5 to-magenta-500/5 hover:border-cyan-400/40 transition-all duration-300">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-400 to-cyan-500 flex items-center justify-center">
                  <Target className="w-6 h-6 text-[#0a1e3a]" />
                </div>
                <h3 className="text-xl font-bold text-white">Missão</h3>
              </div>
              <p className="text-gray-300">
                Apoiar empresas a tomar decisões comerciais e financeiras com mais clareza, velocidade e proteção.
              </p>
            </div>

            <div className="group p-8 rounded-xl border border-cyan-500/20 bg-gradient-to-br from-cyan-500/5 to-magenta-500/5 hover:border-cyan-400/40 transition-all duration-300">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-magenta-400 to-magenta-500 flex items-center justify-center">
                  <Zap className="w-6 h-6 text-[#0a1e3a]" />
                </div>
                <h3 className="text-xl font-bold text-white">Visão</h3>
              </div>
              <p className="text-gray-300">
                Ser a ponte entre a tecnologia Serasa e o sucesso comercial de nossos clientes.
              </p>
            </div>

            <div className="group p-8 rounded-xl border border-cyan-500/20 bg-gradient-to-br from-cyan-500/5 to-magenta-500/5 hover:border-cyan-400/40 transition-all duration-300">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-400 via-magenta-400 to-magenta-500 flex items-center justify-center">
                  <Shield className="w-6 h-6 text-[#0a1e3a]" />
                </div>
                <h3 className="text-xl font-bold text-white">Valores</h3>
              </div>
              <p className="text-gray-300">
                Clareza, integridade, foco em resultado e acompanhamento próximo com nossos clientes.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Diferenciais com Imagem */}
      <section className="py-20 border-b border-cyan-500/20">
        <div className="container">
          <h2 className="text-4xl font-bold mb-4 text-white">Nossos Diferenciais</h2>
          <p className="text-lg text-gray-300 mb-16 max-w-2xl">
            Tecnologia com leitura comercial e visão de negócio
          </p>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="group p-6 rounded-xl border border-cyan-500/20 bg-gradient-to-br from-cyan-500/5 to-transparent hover:border-cyan-400/40 transition-all duration-300">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-400 to-cyan-500 flex items-center justify-center flex-shrink-0">
                    <Users className="w-6 h-6 text-[#0a1e3a]" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold mb-2 text-white">Visão Comercial</h3>
                    <p className="text-gray-300">
                      Conectamos produto à dor real, com linguagem de negócio que seus clientes entendem.
                    </p>
                  </div>
                </div>
              </div>

              <div className="group p-6 rounded-xl border border-cyan-500/20 bg-gradient-to-br from-cyan-500/5 to-transparent hover:border-cyan-400/40 transition-all duration-300">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-magenta-400 to-magenta-500 flex items-center justify-center flex-shrink-0">
                    <TrendingUp className="w-6 h-6 text-[#0a1e3a]" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold mb-2 text-white">Curadoria de Soluções</h3>
                    <p className="text-gray-300">
                      Indicamos o que faz sentido para o momento e maturidade do seu cliente.
                    </p>
                  </div>
                </div>
              </div>

              <div className="group p-6 rounded-xl border border-cyan-500/20 bg-gradient-to-br from-cyan-500/5 to-transparent hover:border-cyan-400/40 transition-all duration-300">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-400 via-magenta-400 to-magenta-500 flex items-center justify-center flex-shrink-0">
                    <Zap className="w-6 h-6 text-[#0a1e3a]" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold mb-2 text-white">Acompanhamento Próximo</h3>
                    <p className="text-gray-300">
                      Apoio na ativação para que a solução seja usada e gere resultado real.
                    </p>
                  </div>
                </div>
              </div>

              <div className="group p-6 rounded-xl border border-cyan-500/20 bg-gradient-to-br from-cyan-500/5 to-transparent hover:border-cyan-400/40 transition-all duration-300">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-magenta-400 via-cyan-400 to-cyan-500 flex items-center justify-center flex-shrink-0">
                    <Shield className="w-6 h-6 text-[#0a1e3a]" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold mb-2 text-white">Governança da Decisão</h3>
                    <p className="text-gray-300">
                      Reforçamos método, processo e clareza na jornada de crédito do cliente.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="relative">
              <img 
                src="/manus-storage/analise-credito_174a1131.png"
                alt="Análise de Crédito"
                className="rounded-xl border border-cyan-500/20 shadow-2xl"
              />
              <div className="absolute inset-0 rounded-xl bg-gradient-to-t from-[#0a1e3a] via-transparent to-transparent opacity-40"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Públicos-Alvo */}
      <section className="py-20 border-b border-cyan-500/20">
        <div className="container">
          <h2 className="text-4xl font-bold mb-4 text-white">Onde Geramos Valor</h2>
          <p className="text-lg text-gray-300 mb-16 max-w-2xl">
            Servimos empresas que vendem, concedem crédito ou precisam proteger receita
          </p>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {["Indústria", "Atacado e Distribuição", "Varejo", "Serviços", "Educação", "Financeiras e Fintechs", "Construtoras", "Tecnologia"].map((segment, i) => (
              <div key={i} className="p-6 rounded-lg border border-cyan-500/20 bg-gradient-to-br from-cyan-500/10 to-magenta-500/10 text-center hover:border-cyan-400/40 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <p className="font-medium text-white">{segment}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-gradient-to-r from-[#0a1e3a] via-cyan-500/10 to-[#0a1e3a] border-b border-cyan-500/20">
        <div className="container text-center">
          <h2 className="text-4xl font-bold mb-6 text-white">Pronto para Começar?</h2>
          <p className="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">
            Faça um diagnóstico gratuito e descubra como podemos ajudar sua empresa.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/diagnostic">
              <Button className="bg-cyan-500 hover:bg-cyan-600 text-[#0a1e3a] font-bold px-8 py-3 rounded-lg transition-all duration-300">
                Fazer Diagnóstico Gratuito <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </Link>
            <Link href="/">
              <Button variant="outline" className="border-cyan-400/50 text-cyan-400 hover:bg-cyan-400/10 px-8 py-3 rounded-lg transition-all duration-300">
                Voltar para Home
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#051018] text-gray-400 py-12 border-t border-cyan-500/20">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <img src={COMPANY_DATA.logo} alt={COMPANY_DATA.name} className="h-12 object-contain mb-3" />
              <p className="text-sm text-gray-400">{COMPANY_DATA.tagline}</p>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">Navegação</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="/" className="text-gray-400 hover:text-cyan-400 transition-colors">Home</Link></li>
                <li><Link href="/about" className="text-gray-400 hover:text-cyan-400 transition-colors">Quem Somos</Link></li>
                <li><Link href="/products" className="text-gray-400 hover:text-cyan-400 transition-colors">Produtos</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">Contato</h4>
              <ul className="space-y-2 text-sm">
                <li><a href={`tel:${COMPANY_DATA.phone}`} className="text-gray-400 hover:text-cyan-400 transition-colors">{COMPANY_DATA.phone}</a></li>
                <li><a href={`mailto:${COMPANY_DATA.email}`} className="text-gray-400 hover:text-cyan-400 transition-colors">{COMPANY_DATA.email}</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-4">Redes Sociais</h4>
              <ul className="space-y-2 text-sm">
                <li><a href={COMPANY_DATA.social.linkedin} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-cyan-400 transition-colors">LinkedIn</a></li>
                <li><a href={COMPANY_DATA.social.instagram} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-cyan-400 transition-colors">Instagram</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-cyan-500/20 pt-8 text-center text-sm text-gray-500">
            <p>&copy; 2026 ScoreSense. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
