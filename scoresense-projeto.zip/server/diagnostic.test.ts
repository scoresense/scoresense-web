import { describe, it, expect, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";

describe("Diagnostic Router", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should calculate low risk score for small retail business", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: {} as any,
      res: {} as any,
    });

    const result = await caller.diagnostic.submit({
      name: "João Silva",
      company: "Loja Pequena",
      position: "Gerente",
      whatsapp: "47999999999",
      email: "joao@email.com",
      segment: "retail",
      clientVolume: "0-50",
      salesModel: "cash",
      mainPain: "default",
      currentSolution: "Controle manual",
    });

    expect(result.score).toBeLessThanOrEqual(25);
    expect(result.riskLevel).toBe("low");
    expect(result.leadId).toBeDefined();
  });

  it("should calculate high risk score for large wholesale business with credit sales", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: {} as any,
      res: {} as any,
    });

    const result = await caller.diagnostic.submit({
      name: "Maria Santos",
      company: "Distribuição NAFI",
      position: "Diretora",
      whatsapp: "47988888888",
      email: "maria@nafi.com",
      segment: "wholesale",
      clientVolume: "500+",
      salesModel: "credit",
      mainPain: "multiple",
      currentSolution: "",
    });

    expect(result.score).toBeGreaterThan(50);
    expect(result.riskLevel).toMatch(/high|critical/);
    expect(result.recommendation).toBeDefined();
    expect(result.leadId).toBeDefined();
  });

  it("should require all mandatory fields", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: {} as any,
      res: {} as any,
    });

    try {
      await caller.diagnostic.submit({
        name: "",
        company: "Test Company",
        position: "Manager",
        whatsapp: "47999999999",
        segment: "distribution",
        clientVolume: "51-200",
        salesModel: "mixed",
        mainPain: "fraud",
      } as any);
      expect.fail("Should have thrown validation error");
    } catch (error: any) {
      expect(error.message).toContain("obrigatório");
    }
  });

  it("should provide specific recommendation based on risk level and pain", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: {} as any,
      res: {} as any,
    });

    const result = await caller.diagnostic.submit({
      name: "Pedro Costa",
      company: "Distribuição SC",
      position: "Gerente de Crédito",
      whatsapp: "47987654321",
      email: "pedro@dist.com",
      segment: "distribution",
      clientVolume: "201-500",
      salesModel: "credit",
      mainPain: "fraud",
      currentSolution: "Validação manual de CPF",
    });

    expect(result.recommendation).toBeDefined();
    expect(result.recommendation.length).toBeGreaterThan(0);
  });
});

describe("Appointment Router", () => {
  it("should create appointment lead successfully", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: {} as any,
      res: {} as any,
    });

    const result = await caller.appointment.submit({
      name: "Ana Silva",
      company: "Atacado Regional",
      position: "Diretora Financeira",
      whatsapp: "47999888777",
      email: "ana@atacado.com",
      preferredDate: "2026-06-15",
      preferredTime: "14:00",
      notes: "Interessada em análise de crédito",
    });

    expect(result.leadId).toBeDefined();
    expect(result.appointmentId).toBeDefined();
  });

  it("should accept appointment without preferred date/time", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: {} as any,
      res: {} as any,
    });

    const result = await caller.appointment.submit({
      name: "Carlos Mendes",
      company: "Distribuição ABC",
      position: "Gerente",
      whatsapp: "47998877665",
      email: "carlos@abc.com",
    });

    expect(result.leadId).toBeDefined();
    expect(result.appointmentId).toBeDefined();
  });
});

describe("Admin Router", () => {
  it("should require admin role to list leads", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: {} as any,
      res: {} as any,
    });

    try {
      await caller.admin.leads.list({});
      expect.fail("Should have thrown unauthorized error");
    } catch (error: any) {
      expect(error.message).toContain("Unauthorized");
    }
  });

  it("should allow admin to list leads", async () => {
    const adminUser = {
      id: 1,
      openId: "admin-user",
      name: "Admin",
      email: "admin@example.com",
      role: "admin" as const,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
      loginMethod: "manus",
    };

    const caller = appRouter.createCaller({
      user: adminUser,
      req: {} as any,
      res: {} as any,
    });

    const result = await caller.admin.leads.list({});
    expect(Array.isArray(result)).toBe(true);
  });
});
