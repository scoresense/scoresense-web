import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { createLeadWithDiagnostic, createLeadFromAppointment, getAllLeads, getLeadWithDiagnostic, updateLeadStatus, subscribeNewsletter, getPublishedPosts, getPostBySlug, getPostsByCategory, createBlogPost, updateBlogPost, deleteBlogPost } from "./db";
import { notifyOwner } from "./_core/notification";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Diagnostic router
  diagnostic: router({
    submit: publicProcedure
      .input(
        z.object({
          name: z.string().min(1, "Nome é obrigatório"),
          company: z.string().min(1, "Empresa é obrigatória"),
          position: z.string().min(1, "Cargo é obrigatório"),
          whatsapp: z.string().min(10, "WhatsApp inválido"),
          email: z.string().email().optional(),
          segment: z.enum(["distribution", "wholesale", "retail", "other"]),
          clientVolume: z.enum(["0-50", "51-200", "201-500", "500+"]),
          salesModel: z.enum(["cash", "credit", "mixed"]),
          mainPain: z.enum(["default", "fraud", "creditDecision", "collection", "multiple"]),
          currentSolution: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        // Calculate score
        let score = 0;
        
        // Segment scoring
        if (["distribution", "wholesale"].includes(input.segment)) score += 25;
        else if (input.segment === "retail") score += 15;
        else score += 5;
        
        // Client volume scoring
        const volumeScores: Record<string, number> = {
          "0-50": 10,
          "51-200": 15,
          "201-500": 20,
          "500+": 25,
        };
        score += volumeScores[input.clientVolume] || 0;
        
        // Sales model scoring
        const modelScores: Record<string, number> = {
          "cash": 5,
          "mixed": 15,
          "credit": 25,
        };
        score += modelScores[input.salesModel] || 0;
        
        // Main pain scoring
        const painScores: Record<string, number> = {
          "default": 5,
          "collection": 10,
          "fraud": 20,
          "creditDecision": 20,
          "multiple": 25,
        };
        score += painScores[input.mainPain] || 0;
        
        // Current solution scoring
        if (!input.currentSolution) score += 10;
        else if (input.currentSolution.length < 20) score += 5;
        
        // Determine risk level
        let riskLevel: "low" | "medium" | "high" | "critical";
        if (score <= 25) riskLevel = "low";
        else if (score <= 50) riskLevel = "medium";
        else if (score <= 75) riskLevel = "high";
        else riskLevel = "critical";
        
        // Generate recommendation
        const recommendations: Record<string, string> = {
          "critical_fraud": "Consulta de CPF/CNPJ + Validação Cadastral + Monitoramento Contínuo",
          "critical_creditDecision": "Análise de Crédito Completa + Score de Risco + Monitoramento",
          "critical_default": "Análise de Crédito + Monitoramento de Risco + Suporte a Cobrança",
          "high_fraud": "Validação Cadastral + Monitoramento de Risco",
          "high_creditDecision": "Análise de Crédito + Score de Risco",
          "high_default": "Análise de Crédito + Monitoramento",
          "medium_default": "Consulta Básica + Monitoramento",
          "low_default": "Consulta de Informações Cadastrais",
        };
        
        const recommendationKey = `${riskLevel}_${input.mainPain === "multiple" ? "default" : input.mainPain}`;
        const recommendation = recommendations[recommendationKey] || recommendations["medium_default"];
        
        // Create lead and diagnostic
        const { lead, diagnostic } = await createLeadWithDiagnostic(
          {
            name: input.name,
            company: input.company,
            position: input.position,
            whatsapp: input.whatsapp,
            email: input.email,
            source: "diagnostic",
            status: "new",
          },
          {
            segment: input.segment,
            clientVolume: input.clientVolume,
            salesModel: input.salesModel,
            mainPain: input.mainPain,
            currentSolution: input.currentSolution,
            score,
            riskLevel,
            recommendation,
          }
        );
        
        // Notify owner if high-quality lead
        if (score >= 51) {
          await notifyOwner({
            title: `Novo Lead Qualificado: ${input.company}`,
            content: `${input.name} (${input.position}) de ${input.company}\nScore: ${score}/100 (${riskLevel})\nPrincipal dor: ${input.mainPain}\nWhatsApp: ${input.whatsapp}`,
          });
        }
        
        return {
          leadId: lead.id,
          score,
          riskLevel,
          recommendation,
        };
      }),
  }),

  // Appointment router
  appointment: router({
    submit: publicProcedure
      .input(
        z.object({
          name: z.string().min(1, "Nome é obrigatório"),
          company: z.string().min(1, "Empresa é obrigatória"),
          position: z.string().min(1, "Cargo é obrigatório"),
          whatsapp: z.string().min(10, "WhatsApp inválido"),
          email: z.string().email().optional(),
          preferredDate: z.string().optional(),
          preferredTime: z.string().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { lead, appointment } = await createLeadFromAppointment(
          {
            name: input.name,
            company: input.company,
            position: input.position,
            whatsapp: input.whatsapp,
            email: input.email,
            source: "appointment",
            status: "new",
          },
          {
            preferredDate: input.preferredDate ? new Date(input.preferredDate) : undefined,
            preferredTime: input.preferredTime,
            notes: input.notes,
          }
        );
        
        // Notify owner
        await notifyOwner({
          title: `Novo Agendamento Solicitado: ${input.company}`,
          content: `${input.name} (${input.position}) de ${input.company}\nData preferida: ${input.preferredDate || "Não especificada"}\nHorário: ${input.preferredTime || "Não especificado"}\nWhatsApp: ${input.whatsapp}`,
        });
        
        return {
          leadId: lead.id,
          appointmentId: appointment.id,
        };
      }),
  }),

  // Admin router
  admin: router({
    leads: router({
      list: protectedProcedure
        .input(
          z.object({
            status: z.string().optional(),
            source: z.string().optional(),
            limit: z.number().optional(),
            offset: z.number().optional(),
          })
        )
        .query(async ({ ctx, input }) => {
          if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
          return getAllLeads(input);
        }),
      getById: protectedProcedure
        .input(z.object({ id: z.number() }))
        .query(async ({ ctx, input }) => {
          if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
          return getLeadWithDiagnostic(input.id);
        }),
      updateStatus: protectedProcedure
        .input(z.object({ id: z.number(), status: z.string() }))
        .mutation(async ({ ctx, input }) => {
          if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
          await updateLeadStatus(input.id, input.status);
          return { success: true };
        }),
    }),
  }),

  // Newsletter router
  newsletter: router({
    subscribe: publicProcedure
      .input(
        z.object({
          email: z.string().email("E-mail inválido"),
          name: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        try {
          await subscribeNewsletter({
            email: input.email,
            name: input.name || null,
            status: "subscribed",
          });

          // Notificar o proprietário sobre o novo inscrito
          await notifyOwner({
            title: "Novo inscrito na newsletter ScoreSense",
            content: `Nome: ${input.name || "Não informado"}\nE-mail: ${input.email}\nData: ${new Date().toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" })}`,
          });

          return { success: true, message: "Inscrição realizada com sucesso!" };
        } catch (error: any) {
          if (error.message?.includes("Duplicate entry")) {
            return { success: true, message: "E-mail já inscrito!" };
          }
          throw error;
        }
      }),
  }),

  // Blog router
  blog: router({
    list: publicProcedure
      .input(
        z.object({
          limit: z.number().default(10),
          offset: z.number().default(0),
        })
      )
      .query(async ({ input }) => {
        return await getPublishedPosts(input.limit, input.offset);
      }),
    getBySlug: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input }) => {
        return await getPostBySlug(input.slug);
      }),
    getByCategory: publicProcedure
      .input(
        z.object({
          category: z.string(),
          limit: z.number().default(10),
          offset: z.number().default(0),
        })
      )
      .query(async ({ input }) => {
        return await getPostsByCategory(input.category, input.limit, input.offset);
      }),
    seedInitialPosts: protectedProcedure
      .mutation(async ({ ctx }) => {
        if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
        
        const initialPosts = [
          {
            title: "Por Que Sua Empresa Perde Vendas Por Insegurança no Crédito",
            slug: "por-que-empresa-perde-vendas-inseguranca-credito",
            excerpt: "A insegurança no crédito custa caro. Empresas sem análise estruturada perdem entre 15-30% de vendas potenciais. Descubra como dados transformam decisões.",
            category: "credito" as const,
            author: "ScoreSense",
            status: "published" as const,
            content: `<h2>A Realidade: Decisões de Crédito Sem Dados = Perdas Reais</h2><p>Você já vivenciou isso? Um cliente com perfil excelente bate à porta, quer fazer uma grande compra, mas sua equipe de crédito diz não porque "não tem certeza". Resultado: venda perdida, receita não realizada, oportunidade que não volta.</p><p>Este cenário é mais comum do que você imagina. De acordo com dados do mercado de crédito brasileiro, empresas que operam sem análise estruturada perdem entre 15% e 30% de vendas potenciais por rejeição conservadora.</p><h2>O Custo Invisível da Insegurança</h2><p>A insegurança no crédito se manifesta de três formas:</p><h3>1. Rejeição de Clientes Bons</h3><p>Quando você não tem dados estruturados, a análise fica subjetiva. Sua equipe tende a dizer "não" para evitar risco. Resultado: clientes bons, com histórico de pagamento excelente, são recusados simplesmente porque faltam informações verificáveis.</p><h3>2. Aprovação de Clientes Ruins</h3><p>Por outro lado, sem dados também acontece o oposto: clientes com risco alto passam porque alguém "confia no olho". Quando a fatura vence, são inadimplentes crônicos que consomem tempo de cobrança e dinheiro em perdas.</p><h3>3. Processo Lento e Burocrático</h3><p>Sem automação, cada decisão leva horas. O cliente espera, a oportunidade esfria, a venda morre. Enquanto isso, seus competidores que têm processo ágil já fecharam o negócio.</p><h2>Os Números Por Trás Disso</h2><p>Dados da Serasa mostram que:</p><ul><li><strong>78% das empresas</strong> que não usam análise estruturada têm taxa de inadimplência acima de 5%</li><li><strong>Tempo médio de decisão sem dados:</strong> 24-48 horas</li><li><strong>Tempo médio com análise estruturada:</strong> 5-10 minutos</li><li><strong>Redução de risco:</strong> até 85% quando você usa dados em tempo real</li></ul><h2>O que Muda Quando Você Tem Inteligência de Dados</h2><p>Empresas que estruturam sua análise de crédito com dados reais conseguem:</p><h3>✓ Aprovar Mais, Sem Aumentar Risco</h3><p>Quando você conhece o real perfil de cada cliente (histórico, capacidade de pagamento, comportamento), consegue aproveitar oportunidades que parecem arriscadas, mas não são.</p><h3>✓ Decidir em Minutos, Não em Dias</h3><p>Com análise automatizada, sua equipe deixa de ser "guardiã do não" e passa a ser "estratégia de crescimento". O cliente recebe resposta rápido, fecha a venda, todo mundo ganha.</p><h3>✓ Reduzir Inadimplência Drasticamente</h3><p>Quando você rejeita os riscos reais e aprova os bons clientes, sua carteira fica saudável. Menos tempo em cobrança, mais caixa em dia.</p><h3>✓ Ganhar Vantagem Competitiva</h3><p>Enquanto seus concorrentes dizem "não, vamos analisar", você já fecha o negócio. Cliente feliz volta, indica amigos, seu negócio cresce.</p><h2>Começar é Mais Simples do que Você Pensa</h2><p>Você não precisa de um projeto gigante. Começa simples:</p><ol><li><strong>Entenda seu perfil atual:</strong> Qual é sua taxa de inadimplência hoje? Quanto você perde em rejeições? Quanto tempo sua equipe gasta em análise?</li><li><strong>Implemente dados:</strong> Use informações estruturadas do mercado (Score de Crédito, histórico Serasa, análise de risco)</li><li><strong>Automatize decisões:</strong> Crie regras claras: "score acima de X = aprova", "score abaixo de Y = nega"</li><li><strong>Monitore e ajuste:</strong> Acompanhe resultados, refine suas políticas</li></ol><h2>Próximo Passo: Diagnóstico</h2><p>Não sabemos qual é a sua situação específica. Mas você pode descobrir em poucos minutos.</p><p>Faça nosso diagnóstico gratuito: responda 5 perguntas rápidas sobre seu negócio, volume de crédito e desafios atuais. Você receberá uma recomendação personalizada de quais dados e análises você realmente precisa.</p><p><strong>Resultado?</strong> Você vende mais, com segurança. Seu caixa fica saudável. Sua equipe trabalha menos em análise, mais em estratégia.</p>`,
            imageUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663713649261/2s2DSoWp9LTztrQtUtQF67/hero-credit-tech-anoszzfD7SmF82eAk27G2y.webp",
          },
          {
            title: "O que é Score de Crédito e Por Que Você Precisa Acompanhar",
            slug: "o-que-e-score-de-credito-por-que-precisa-acompanhar",
            excerpt: "Score de crédito é o termômetro da saúde financeira de cada cliente. Saiba como funciona e por que deve integrar isso na sua operação.",
            category: "serasa" as const,
            author: "ScoreSense",
            status: "published" as const,
            content: `<h2>Score de Crédito: O Termômetro da Saúde Financeira</h2><p>Imagine que você pudesse "medir" a saúde financeira de cada cliente em um número, de 0 a 1000. Um número que reflete historicamente como aquela pessoa (ou empresa) pagou suas dívidas. Um número que te ajuda a decidir: "vale a pena emprestar para esse cliente?"</p><p>Esse número existe. É chamado de Score de Crédito.</p><p>E não, não é mágica. É pura matemática aplicada a dados reais.</p><h2>O Que É Score de Crédito?</h2><p>Score de crédito é um número (geralmente entre 0 e 1000) que representa a probabilidade de uma pessoa ou empresa pagar suas dívidas no prazo.</p><p>Ele é calculado por empresas especializadas em crédito — como a Serasa — usando informações como:</p><ul><li><strong>Histórico de pagamentos:</strong> Essa pessoa pagou no prazo antes? Quantas vezes atrasou?</li><li><strong>Volume de dívidas:</strong> Quanto essa pessoa deve atualmente? Em relação à sua renda, é muito?</li><li><strong>Tipos de crédito:</strong> Ela tem experiência com diferentes tipos (cartão, financiamento, cheque)?</li><li><strong>Idade do histórico:</strong> Há quanto tempo essa pessoa tem histórico de crédito?</li><li><strong>Consultas recentes:</strong> Quantas vezes ela pediu crédito nos últimos meses?</li></ul><p>Tudo junto, esses dados são processados por um modelo matemático que sai: "essa pessoa tem score 750. Risco baixo de inadimplência."</p><h2>Como Funciona na Prática</h2><p>Você está vendendo para um novo cliente. Ele quer comprar R$ 50 mil em produtos, pagamento em 30 dias.</p><p>Sem score:</p><ul><li>Você liga, pede referências, fala com o antigo fornecedor, leva 2 dias</li><li>Ainda assim, não tem certeza se ele vai pagar</li><li>Aprova "na confiança" ou rejeita por medo</li></ul><p>Com score:</p><ul><li>Você consulta o Score do cliente na Serasa: 820</li><li>Seu sistema automaticamente aprova (porque sua política é: score acima de 750 = aprova)</li><li>Cliente recebe resposta em 2 minutos</li><li>Venda fechada</li></ul><h2>Os Patamares do Score</h2><p>Geralmente o Score é interpretado assim:</p><ul><li><strong>0-300:</strong> Risco altíssimo. Evite.</li><li><strong>300-600:</strong> Risco alto. Exija garantias ou não venda.</li><li><strong>600-700:</strong> Risco médio. Considere vender, mas com regras claras de crédito.</li><li><strong>700-850:</strong> Risco baixo. Aprove normalmente.</li><li><strong>850+:</strong> Risco muito baixo. Cliente excelente.</li></ul><p><em>Nota: Esses patamares variam por instituição e por tipo de crédito. A Serasa tem seus próprios modelos.</em></p><h2>Por Que Você Deve Acompanhar o Score dos Seus Clientes</h2><p>Se você já vende para clientes, eles têm score. A pergunta é: você está acompanhando?</p><h3>1. Prevenir Inadimplência Antes Que Aconteça</h3><p>Score não é estático. Se um cliente tinha score 750 e agora tem 550, algo mudou. Pode ser que ele tenha pego crédito demais em outros lugares, ou começou a atrasar. Isso é um sinal vermelho. Você pode:</p><ul><li>Reduzir o limite que você oferece a ele</li><li>Exigir adiantamento no próximo pedido</li><li>Monitorar mais de perto</li></ul><p>Você previne antes de ele virar um inadimplente crônico.</p><h3>2. Aumentar Limite para Bons Clientes</h3><p>Se um cliente sempre pagou no prazo com você, e o score dele está subindo, é sinal de que ele é confiável. Você pode:</p><ul><li>Oferecer prazos maiores (30 dias virando 60 dias)</li><li>Aumentar limite de crédito</li><li>Oferecer condições melhores (desconto por volume)</li></ul><p>Isso mantém o cliente feliz, aumenta vendas, reduz risco. Win-win.</p><h3>3. Tomar Decisões Baseadas em Dados, Não em Feeling</h3><p>Score tira a subjetividade. Você não está decidindo "acho que ele é confiável". Você está decidindo "os dados mostram que ele tem 85% de probabilidade de pagar".</p><p>Sua equipe trabalha com clareza. Sem vieses. Sem medo injustificado.</p><h2>Score Está Disponível Para Todos</h2><p>Você pode consultar o score de CPF ou CNPJ na Serasa. Alguns pontos importantes:</p><ul><li><strong>Pessoa Física (CPF):</strong> Qualquer um pode ter score. Basta ter histórico de crédito.</li><li><strong>Pessoa Jurídica (CNPJ):</strong> Empresas também têm score, baseado no histórico de crédito da empresa.</li><li><strong>Atualização:</strong> Score é atualizado regularmente (a cada nova informação).</li><li><strong>Acesso:</strong> Você pode consultar via plataformas integradas ou pedidos ad-hoc.</li></ul><h2>O Próximo Passo: Integrar Score Na Sua Operação</h2><p>Se você ainda não usa score de crédito, está deixando dinheiro na mesa.</p><p>Começa simples:</p><ol><li><strong>Entenda seu cenário:</strong> Qual é sua taxa de inadimplência hoje? Quanto você aprova "no feeling"?</li><li><strong>Consulte score:</strong> Comece a pedir dados de crédito para novos clientes.</li><li><strong>Defina suas regras:</strong> "Se score > 700, aprova. Se < 600, nega. Se 600-700, analisa manual".</li><li><strong>Monitore carteira:</strong> Acompanhe os scores dos seus clientes atuais mensalmente.</li></ol><p>Resultado? Você reduz inadimplência, aprova mais vendas boas, sua equipe trabalha menos na análise manual.</p><p><strong>Quer estruturar isso na sua empresa?</strong> Nosso diagnóstico gratuito ajuda você a entender como score de crédito pode se encaixar no seu processo de vendas.</p>`,
            imageUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663713649261/2s2DSoWp9LTztrQtUtQF67/hero-credit-tech-anoszzfD7SmF82eAk27G2y.webp",
          },
          {
            title: "Como Organizar e Priorizar Cobranças com Dados",
            slug: "como-organizar-priorizar-cobrancas-com-dados",
            excerpt: "Cobrança reativa é ineficiente. Descubra como dados e segmentação transformam sua taxa de recuperação de 40% para 75%.",
            category: "cobranca" as const,
            author: "ScoreSense",
            status: "published" as const,
            content: `<h2>O Problema Real: Cobrança Reativa vs Cobrança Inteligente</h2><p>Sua equipe de cobrança funciona assim?</p><p>"Hoje é dia 15 do mês. Tira aí a lista de inadimplentes. Começa a ligar para todo mundo. Liga, liga, liga... alguns respondem, alguns não. Alguns pagam, alguns não. No final do mês, você tem uma taxa de recuperação de 40%, e sua equipe está esgotada."</p><p>Isso é cobrança reativa. E é ineficiente.</p><p>Problema: você está tratando todo cliente inadimplente igualmente. O cliente que atrasou 5 dias recebe a mesma pressão que o cliente que deve há 6 meses. O cliente que tem capacidade de pagar mas "esqueceu" é abordado da mesma forma que o cliente que não tem dinheiro mesmo.</p><p>Resultado? Baixa taxa de recuperação, relacionamento danificado, equipe queimada.</p><h2>Cobrança Inteligente: Dados + Estratégia</h2><p>Agora imagine isso:</p><p>Você tem uma plataforma que organiza seus inadimplentes por:</p><ul><li><strong>Risco de recuperação:</strong> Clientes com histórico de pagamento podem ser recuperados com uma ligação. Clientes crônicos podem ser escalados para cobrança judiciária.</li><li><strong>Potencial de recuperação:</strong> Quanto cada cliente deve? Vale a pena gastar tempo em cobrança?</li><li><strong>Prioridade:</strong> Quem deve mais? Quem atrasou menos? Quem é mais provável de pagar?</li><li><strong>Estratégia de abordagem:</strong> Qual é o melhor canal para cada cliente? Ligação, SMS, e-mail, visita presencial?</li><li><strong>Histórico de contato:</strong> Já ligamos para esse cliente? Quantas vezes? Qual foi a resposta?</li></ul><p>Com isso, sua equipe deixa de fazer "cobrança em massa" e passa a fazer "cobrança estratégica".</p><h2>Os Números da Cobrança Desorganizada vs Organizada</h2><p>Dados do mercado mostram:</p><ul><li><strong>Taxa de recuperação sem priorização:</strong> 35-45%</li><li><strong>Taxa de recuperação com priorização inteligente:</strong> 65-80%</li><li><strong>Economia de tempo:</strong> 60% menos tempo de ligação improdutiva</li><li><strong>Custo por recuperação:</strong> Reduz até 40%</li></ul><p>A diferença não é pequena. A diferença é transformacional.</p><h2>Como Estruturar Cobrança com Dados</h2><h3>1. Segmente Seus Inadimplentes</h3><p>Não trate todo mundo igual. Crie grupos:</p><ul><li><strong>Prioridade 1:</strong> Atraso de 5-15 dias. Cliente bom. Estratégia: uma ligação rápida, lembrete educado. Taxa de sucesso: 80%.</li><li><strong>Prioridade 2:</strong> Atraso de 15-30 dias. Pode ser situação temporária. Estratégia: ligação + oferta de parcelamento. Taxa de sucesso: 60%.</li><li><strong>Prioridade 3:</strong> Atraso acima de 30 dias. Pode ser cliente em dificuldade. Estratégia: análise de risco, negociação ou escalação. Taxa de sucesso: 30-40%.</li><li><strong>Prioridade 4:</strong> Atraso acima de 90 dias. Provável perda. Estratégia: cobrança judiciária ou write-off. Taxa de sucesso: <10%.</li></ul><h3>2. Defina Prioridade por Valor</h3><p>Seu tempo é finito. Invista onde o retorno é maior.</p><p>Uma ligação para recuperar R$ 500 tem ROI diferente de uma ligação para recuperar R$ 50 mil. Priorize os maiores.</p><h3>3. Use Score de Crédito Para Previsibilidade</h3><p>Cliente com score em queda é mais provável de não pagar. Cliente com score estável é mais provável de estar apenas "atrasado por preguiça".</p><p>Use score para:</p><ul><li>Prever quem vai pagar (com qual probabilidade)</li><li>Decidir se vale a pena insistir ou desistir</li><li>Oferecer condições melhores aos que têm capacidade mas não têm vontade</li></ul><h3>4. Automatize Contatos</h3><p>Nem todo contato é ligação. Use:</p><ul><li><strong>SMS/WhatsApp:</strong> Para lembretes (atraso < 10 dias). Automático, barato, eficaz.</li><li><strong>E-mail:</strong> Para comunicações formais. Deixa histórico.</li><li><strong>Ligação:</strong> Para cobranças maiores ou clientes difíceis. Gasto maior, mas necessário.</li><li><strong>Carta/Visita:</strong> Para cobranças jurídicas. Escalação final.</li></ul><h3>5. Acompanhe Métricas</h3><p>Meça o que importa:</p><ul><li>Taxa de recuperação por segmento</li><li>Tempo médio para recuperação</li><li>Custo por real recuperado</li><li>Evolução do Score dos seus devedores</li></ul><p>Com isso, você refina sua estratégia continuamente.</p><h2>Exemplo Real</h2><p>Empresa de distribuição com R$ 2 milhões em carteira ativa.</p><p><strong>Antes:</strong></p><ul><li>Taxa de inadimplência: 7%</li><li>Taxa de recuperação: 40%</li><li>Perdas anuais: ~R$ 84 mil</li><li>2 pessoas 100% dedicadas à cobrança</li></ul><p><strong>Depois (6 meses com cobrança inteligente):</strong></p><ul><li>Taxa de inadimplência: 3%</li><li>Taxa de recuperação: 75%</li><li>Perdas anuais: ~R$ 22,5 mil</li><li>1 pessoa 60% dedicada à cobrança (resto do tempo em estratégia)</li></ul><p><strong>Impacto:</strong> Redução de perdas de R$ 61,5 mil/ano. Ganho de produtividade de 1 pessoa.</p><h2>Começar Agora</h2><p>Não precisa ser complexo. Começa assim:</p><ol><li><strong>Mapeie seu cenário:</strong> Qual é sua taxa de inadimplência? Como você cobra hoje?</li><li><strong>Segmente:</strong> Divida inadimplentes por dias de atraso e valor.</li><li><strong>Defina estratégias:</strong> "Cliente <10 dias = SMS. Cliente <30 dias = Ligação. Cliente >30 dias = Escalação".</li><li><strong>Automatize o possível:</strong> SMS, e-mail, relatórios de priorização.</li><li><strong>Acompanhe resultados:</strong> Meça taxa de recuperação, custo por real recuperado.</li></ol><p>Em 3 meses você vê diferença. Em 6 meses, a transformação é clara.</p><p><strong>Quer diagnosticar como sua empresa pode melhorar cobrança?</strong> Faça nosso assessment gratuito. Você descobrirá onde está deixando dinheiro na mesa e qual é a melhor estratégia para você.</p>`,
            imageUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663713649261/2s2DSoWp9LTztrQtUtQF67/hero-credit-tech-anoszzfD7SmF82eAk27G2y.webp",
          },
          {
            title: "Detecção de Fraudes: Como Não Cair em Golpes Cadastrais",
            slug: "deteccao-fraudes-como-nao-cair-golpes-cadastrais",
            excerpt: "Fraudes cadastrais custam bilhões ao ano. Saiba como implementar camadas de detecção para proteger seu negócio.",
            category: "fraude" as const,
            author: "ScoreSense",
            status: "published" as const,
            content: `<h2>A Realidade: Fraudes Cadastrais Custam Bilhões Todo Ano</h2><p>Você recebe uma ligação. É um cliente novo, quer comprar R$ 100 mil em produtos. Diz que vai revender, marcha alta. Promete pagamento em 15 dias. Você consulta o CNPJ dele, tá regularizado, tá tudo certo.</p><p>Você aprova.</p><p>15 dias depois: não paga. Você liga: "Olá, você quer parcelar?" — Silêncio. O CNPJ desaparece. Você descobrir depois que aquela empresa não existe de verdade. O CPF do dono é falso. Você foi fraudado.</p><p>Isso acontece centenas de vezes por dia no Brasil.</p><p>De acordo com a Serasa, fraudes cadastrais custam ao mercado brasileiro mais de R$ 5 bilhões por ano. E o pior: a maioria das fraudes passa por uma simples consulta de CPF/CNPJ.</p><h2>Os Tipos de Fraude Que Você Precisa Conhecer</h2><h3>1. Fraude Cadastral (CPF/CNPJ Falso)</h3><p>A pessoa se identifica com um CPF que não é dela. Ou está usando CPF de terceiro sem consentimento. Ou até mesmo inventou um CPF.</p><p>Como detectar?</p><ul><li>Validação de CPF/CNPJ com órgãos oficiais (Receita Federal, Serasa)</li><li>Cross-check com documentos: foto de ID, por exemplo</li><li>Comportamento suspeito: compra primeira vez em alto volume, não quer negociar prazo, quer fazer tudo rápido</li></ul><h3>2. Fraude Documental</h3><p>A pessoa usa documentos falsos (RG, CNH, passaporte) para se passar por outra pessoa, ou para validar um CPF falso.</p><p>Como detectar?</p><ul><li>Validação de documentos com órgãos emissores</li><li>Análise de segurança (hologramas, numeração, etc)</li><li>Conferência de foto: a pessoa na frente é a mesma do documento?</li></ul><h3>3. Fraude Comportamental</h3><p>Tudo parece legal na documentação, mas o comportamento é estranho:</p><ul><li>Cliente novo quer comprar muito, muito rápido</li><li>Não negocia preço ou prazo (é estranho, normal é negociar)</li><li>Quer levar antes de passar documento/comprovante</li><li>Dados que não batem (endereço, telefone, etc)</li><li>Histórico novo: como ele conseguiu outros créditos se é tão novo?</li></ul><h3>4. Fraude de Identidade (Identity Theft)</h3><p>Alguém usa o CPF/dados de uma pessoa legítima para fazer compras, pedir crédito, etc. A pessoa real só descobre quando a dívida bate à sua porta.</p><h2>Como as Fraudes Passam Despercebidas</h2><p>A maioria das empresas faz só o básico:</p><ol><li>Consulta CPF/CNPJ</li><li>Se existir no banco de dados da Receita Federal, aprova</li><li>Só</li></ol><p>Problema: existir no banco de dados não significa nada. Significa só que aquele número existe. Não significa que a pessoa que está à sua frente é aquela pessoa.</p><p>É como conferir o endereço de uma casa e presumir que você conhece quem mora lá.</p><h2>As Camadas da Detecção de Fraude</h2><p>Fraude séria exige múltiplas camadas de validação:</p><h3>Camada 1: Validação Cadastral</h3><ul><li>CPF/CNPJ é válido?</li><li>Dados básicos batem (nome, data de nascimento)?</li><li>Não está em lista de negativação ou bloqueio?</li></ul><h3>Camada 2: Validação Documental</h3><ul><li>Documento é válido?</li><li>Foto no documento é a mesma pessoa à sua frente (análise biométrica)?</li><li>Documento não é cópia falsa?</li></ul><h3>Camada 3: Validação Comportamental</h3><ul><li>Comportamento da pessoa bate com o CPF/histórico dela?</li><li>Padrão de compra é coerente?</li><li>Score de crédito bate com o volume que está pedindo?</li><li>Há sinais de lavagem de dinheiro (múltiplas compras pequenas quando era pessoa comum)?</li></ul><h3>Camada 4: Validação Inteligente</h3><ul><li>IA analisa padrões de fraude conhecidas</li><li>Compara com banco de dados de fraudes anteriores</li><li>Identifica red flags automáticos</li><li>Prioriza para revisão manual se necessário</li></ul><h2>O Custo da Fraude vs Custo da Prevenção</h2><p>Você pode pensar: "Isso tudo é caro, complexo. Vou deixar passar alguns fraudadores em nome da eficiência."</p><p>Errado.</p><p>Números reais:</p><ul><li><strong>Fraude não detectada:</strong> R$ 100 mil = R$ 100 mil de prejuízo + 2-3 meses investigando</li><li><strong>Sistema de detecção de fraude:</strong> ~R$ 2-5 mil/mês</li></ul><p>Uma fraude detectada cedo te economiza mais que um ano inteiro de sistema.</p><p>Além disso, empresa que sofre fraude ainda carrega o "risco moral": outros fraudadores veem que você é fácil e vêm atrás.</p><h2>Como Implementar Detecção de Fraude</h2><p>Não precisa ser gigante. Começa assim:</p><ol><li><strong>Defina seu perfil de risco:</strong> Cliente novo, primeira compra, alto volume = risco alto. Cliente antigo, compras pequenas, comportamento previsível = risco baixo.</li><li><strong>Implemente validação básica:</strong> CPF/CNPJ válido, documento com foto, conferência de dados.</li><li><strong>Crie regras de alerta:</strong> "Compra >R$ 50 mil de cliente novo = requer aprovação manual".</li><li><strong>Use dados de terceiros:</strong> Consulte bases de fraude conhecidas (Serasa, Equifax, etc).</li><li><strong>Acompanhe fraudes:</strong> Quando descobre uma, registra, analisa padrão, ajusta sistema.</li></ol><h2>Exemplo Real</h2><p>Varejista com R$ 20 milhões/ano em vendas.</p><p><strong>Antes de implementar detecção:</strong></p><ul><li>Taxa de fraude estimada: 0,8% das vendas</li><li>Perdas anuais: ~R$ 160 mil</li><li>Descobria fraude depois do fato (cliente não pagava)</li></ul><p><strong>Depois (com sistema de detecção):</strong></p><ul><li>Taxa de fraude: 0,1% das vendas</li><li>Perdas anuais: ~R$ 20 mil</li><li>Detectava fraude antes de liberar produto</li><li>Investimento em sistema: R$ 3 mil/mês</li></ul><p><strong>Impacto líquido:</strong> Redução de perdas de R$ 140 mil/ano. Custo anual de prevenção: R$ 36 mil. ROI = 288%.</p><h2>Próxima Ação</h2><p>Você está vendendo para clientes sem validação adequada? Sua taxa de fraude é mais alta que deveria?</p><p>Faça nosso diagnóstico gratuito. Vamos entender seu perfil de risco atual, quantas fraudes você pode estar sofrendo, e qual é a melhor estratégia de detecção para sua empresa.</p><p>Porque na verdade, a fraude mais cara é a que você não vê vindo.</p>`,
            imageUrl: "https://d2xsxph8kpxj0f.cloudfront.net/310519663713649261/2s2DSoWp9LTztrQtUtQF67/hero-credit-tech-anoszzfD7SmF82eAk27G2y.webp",
          },
        ];

        // Inserir posts
        for (const post of initialPosts) {
          await createBlogPost({
            ...post,
            publishedAt: new Date(),
          });
        }

        return { success: true, message: "4 posts criados com sucesso!" };
      }),
    create: protectedProcedure
      .input(
        z.object({
          title: z.string().min(5),
          slug: z.string().min(3),
          excerpt: z.string().min(10),
          content: z.string().min(100),
          category: z.enum(["credito", "serasa", "cobranca", "fraude", "tendencias", "educacao"]),
          imageUrl: z.string().optional(),
          author: z.string().optional(),
          status: z.enum(["draft", "published"]).default("draft"),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
        return await createBlogPost({
          ...input,
          author: input.author || "ScoreSense",
        });
      }),
    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          title: z.string().min(5).optional(),
          slug: z.string().min(3).optional(),
          excerpt: z.string().min(10).optional(),
          content: z.string().min(100).optional(),
          category: z.enum(["credito", "serasa", "cobranca", "fraude", "tendencias", "educacao"]).optional(),
          imageUrl: z.string().optional(),
          status: z.enum(["draft", "published"]).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
        const { id, ...data } = input;
        await updateBlogPost(id, data);
        return { success: true };
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user?.role !== "admin") throw new Error("Unauthorized");
        await deleteBlogPost(input.id);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
